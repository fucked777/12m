var searchData=
[
  ['simple_5fstring',['simple_string',['../classcpp__redis_1_1reply.html#acc272b2a52164cac1d110c619a0b25bda42e59301bab38b6e2a173baf105990dd',1,'cpp_redis::reply::simple_string()'],['../classcpp__redis_1_1reply.html#ac192ba4cb8f2bb6e7cb465edf755328ba42e59301bab38b6e2a173baf105990dd',1,'cpp_redis::reply::simple_string()']]],
  ['slave',['slave',['../classcpp__redis_1_1client.html#a388877b01b4e045cddb138e70a68e000a03158cf39c6f316f9ce98a4e034cdc28',1,'cpp_redis::client']]],
  ['sleeping',['sleeping',['../classcpp__redis_1_1client.html#a2512bd48dd45391249a69bd720c1e4daad98cb5df35fc9e0f42fb883d794ad12f',1,'cpp_redis::client::sleeping()'],['../classcpp__redis_1_1subscriber.html#afc976757efd9d0ac4def6935546a2338ad98cb5df35fc9e0f42fb883d794ad12f',1,'cpp_redis::subscriber::sleeping()']]],
  ['start',['start',['../classcpp__redis_1_1client.html#a2512bd48dd45391249a69bd720c1e4daaea2b2676c28c0db26d39331a336c6b92',1,'cpp_redis::client::start()'],['../classcpp__redis_1_1subscriber.html#afc976757efd9d0ac4def6935546a2338aea2b2676c28c0db26d39331a336c6b92',1,'cpp_redis::subscriber::start()']]],
  ['stopped',['stopped',['../classcpp__redis_1_1client.html#a2512bd48dd45391249a69bd720c1e4daaf0a0bfe6bc7d2c58d2989034f83183e0',1,'cpp_redis::client::stopped()'],['../classcpp__redis_1_1subscriber.html#afc976757efd9d0ac4def6935546a2338af0a0bfe6bc7d2c58d2989034f83183e0',1,'cpp_redis::subscriber::stopped()']]]
];
