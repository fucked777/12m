var searchData=
[
  ['wait',['wait',['../classcpp__redis_1_1client.html#ab7e11ccc1fb07ae3dce860042b96f4d9',1,'cpp_redis::client::wait(int numslaves, int timeout, const reply_callback_t &amp;reply_callback)'],['../classcpp__redis_1_1client.html#a4ef6f516a3dcdea1b317bb4e5e96e680',1,'cpp_redis::client::wait(int numslaves, int timeout)']]],
  ['warn',['warn',['../classcpp__redis_1_1logger__iface.html#a0ea8e43a4f2118e77af56cd1cdb21cba',1,'cpp_redis::logger_iface::warn()'],['../classcpp__redis_1_1logger.html#ae9359429428786c7b5605a1109508ae5',1,'cpp_redis::logger::warn()'],['../namespacecpp__redis.html#a8316739706654d185aed3966fad3ec89',1,'cpp_redis::warn()']]],
  ['watch',['watch',['../classcpp__redis_1_1client.html#a7faae4f59e4b7f5b5003dcfbbf04af89',1,'cpp_redis::client::watch(const std::vector&lt; std::string &gt; &amp;keys, const reply_callback_t &amp;reply_callback)'],['../classcpp__redis_1_1client.html#a437606353878a903033ced5cb56ed07c',1,'cpp_redis::client::watch(const std::vector&lt; std::string &gt; &amp;keys)']]]
];
