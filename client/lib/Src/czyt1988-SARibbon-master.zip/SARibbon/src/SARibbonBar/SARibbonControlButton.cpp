﻿#include "SARibbonControlButton.h"

SARibbonControlButton::SARibbonControlButton(QWidget *parent)
    :QToolButton(parent)
{

}
