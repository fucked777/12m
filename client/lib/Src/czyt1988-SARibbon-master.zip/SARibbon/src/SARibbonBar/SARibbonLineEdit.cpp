﻿#include "SARibbonLineEdit.h"
#include <QStyleOption>
SARibbonLineEdit::SARibbonLineEdit(QWidget *parent)
    :QLineEdit(parent)
{

}

