#include "IDictionaryService.h"

IDictionaryService::~IDictionaryService()
{
}
