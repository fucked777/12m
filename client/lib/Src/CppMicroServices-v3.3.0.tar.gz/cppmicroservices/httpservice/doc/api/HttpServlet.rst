HttpServlet
-----------

.. doxygenclass:: cppmicroservices::HttpServlet
