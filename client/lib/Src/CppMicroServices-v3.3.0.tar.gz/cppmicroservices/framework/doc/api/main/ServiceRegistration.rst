ServiceRegistration
-------------------

.. doxygengroup:: gr_serviceregistration
   :content-only:
