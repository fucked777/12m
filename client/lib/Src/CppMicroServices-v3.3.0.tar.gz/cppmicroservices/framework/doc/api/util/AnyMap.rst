AnyMap
------

.. doxygenclass:: cppmicroservices::AnyMap

.. doxygenclass:: cppmicroservices::any_map