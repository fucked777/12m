FrameworkEvent
--------------

.. doxygengroup:: gr_frameworkevent
   :content-only:
