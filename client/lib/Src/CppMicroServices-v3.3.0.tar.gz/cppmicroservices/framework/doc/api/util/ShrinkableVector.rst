ShrinkableVector
----------------

.. doxygenclass:: cppmicroservices::ShrinkableVector
