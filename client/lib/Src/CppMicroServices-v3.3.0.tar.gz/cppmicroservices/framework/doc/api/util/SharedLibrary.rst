SharedLibrary
-------------

.. doxygenclass:: cppmicroservices::SharedLibrary
