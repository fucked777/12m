BundleEventHook
---------------

.. doxygenstruct:: cppmicroservices::BundleEventHook
