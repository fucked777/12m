ServiceFindHook
---------------

.. doxygenstruct:: cppmicroservices::ServiceFindHook
