#include <iostream>

void SayHello()
{
  std::cout << "Hello" << std::endl;
}
