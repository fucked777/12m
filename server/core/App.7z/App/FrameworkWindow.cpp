#include "FrameworkWindow.h"
#include "CppMicroServicesUtility.h"
#include "PlatformInterface.h"
#include "PlatfromDefine.h"
#include "ServiceInfoMap.h"
#include <QAction>
#include <QApplication>
#include <QCloseEvent>
#include <QDebug>
#include <QDesktopWidget>
#include <QDir>
#include <QDockWidget>
#include <QMenuBar>
#include <QMessageBox>
#include <QVBoxLayout>

class FrameworkWindowImpl
{
public:
    BundleContext context;
    ListenerToken listenerToken;

    QList<MenuInfo> menuInfos;      // 菜单信息
    QList<ModuleInfo> moduleInfos;  // 模块信息

    /* 服务的映射信息 */
    ServiceInfoMap serviceInfoMap;
    //    /* 这两个需要同步更新 */
    //    QMap<QString, QWidget*> mWidgetMap; /* 菜单名与控件的映射窗口 */
    //    /* 模块与控件的映射,这里List是考虑一个模块可以创建多个界面的 */
    //    QMap<void*, QList<QWidget*>> mServiceToWidgetMap;

    QList<QAction*> defaultTriggeredActions;  // 启动默认触发的菜单

    FrameworkWindowImpl(cppmicroservices::BundleContext context_)
        : context(context_)
    {
    }
};

FrameworkWindow::FrameworkWindow(cppmicroservices::BundleContext context, QWidget* parent)
    : QMainWindow(parent)
    , m_impl(new FrameworkWindowImpl(context))
{
    qRegisterMetaType<ServiceReferenceU>("ServiceReferenceU");

    m_impl->listenerToken = m_impl->context.AddServiceListener([=](const ServiceEvent& event) {
        std::string objectClass = ref_any_cast<std::vector<std::string>>(event.GetServiceReference().GetProperty(Constants::OBJECTCLASS)).front();

        if (event.GetType() == ServiceEvent::SERVICE_REGISTERED)
        {
            qDebug() << "Ex1: Service of type " << QString::fromStdString(objectClass) << " registered.";
            signalInstallGuiServices(event.GetServiceReference());
        }
        else if (event.GetType() == ServiceEvent::SERVICE_UNREGISTERING)
        {
            qDebug() << "Ex1: Service of type " << QString::fromStdString(objectClass) << " unregistered.";

            signalUninstallGuiServices(event.GetServiceReference());
        }
        else if (event.GetType() == ServiceEvent::SERVICE_MODIFIED)
        {
            qDebug() << "Ex1: Service of type " << QString::fromStdString(objectClass) << " modified.";
            signalUninstallGuiServices(event.GetServiceReference());
            signalInstallGuiServices(event.GetServiceReference());
        }
    });
    connect(this, &FrameworkWindow::signalUninstallGuiServices, this, &FrameworkWindow::uninstallGuiServices, Qt::QueuedConnection);

    /*
     * qApp->setStyleSheet("QTabBar::tab {"
                        "height: 40px;"
                        "color: #303133;"
                        "background-color: white;"
                        "border: 1px solid #e4e7ed;"
                        "border-bottom: none;"
                        "padding-left: 20px;"
                        "padding-right: 20px;"
                        "}"
                        "QTabBar::tab:hover {"
                        "color: #409eff;"
                        "}"
                        "QTabBar::tab:selected {"
                        "color: #409eff;"
                        "border-bottom: 2px solid #409eff;"
                        "}"

                        "QGroupBox {"
                        "border: 2px solid #c7c7c7;"
                        "border-radius: 5px;"
                        "margin-top: 1ex;"
                        "}"
                        "QGroupBox::title {"
                        "subcontrol-origin: margin;"
                        "subcontrol-position: top left; "
                        "padding: 0;"
                        "left: 6px;"
                        "}"

                        "QPushButton {"
                        "color:white;"
                        "border-radius: 6px;"
                        "min-width: 80px;"
                        "min-height: 30px;"
                        "}"
                        "QPushButton:enabled {"
                        "background-color: #409eff;"
                        "}"
                        "QPushButton:disabled {"
                        "background-color: #909399;"
                        "}"
                        "QPushButton:hover {"
                        "background-color: #66b1ff;"
                        "}"
                        "QPushButton:pressed {"
                        "background-color: #409eff;"
                        "}"

                        "QToolTip {"
                        "background-color: white;"
                        "border: 2px solid white;"
                        "color: black;"
                        "}"

                        "QScrollBar:vertical {"
                        "width: 6px;"
                        "background-color: transparent;"
                        "margin: 16px 0 16px 0;"
                        "}"
                        "QScrollBar::handle:vertical {"
                        "background: #dddee0;"
                        "min-height: 16px;"
                        "border-radius: 2px;"
                        "}"
                        "QScrollBar::handle:vertical:hover {"
                        "background: #c7c9cc;"
                        "}"
                        "QScrollBar::add-line:vertical {"
                        "background-color: red;"
                        "height: 0px;"
                        "}"
                        "QScrollBar::sub-line:vertical {"
                        "background-color: red;"
                        "height: 0px;"
                        "}"

    );
    */

    packTest();
}

FrameworkWindow::~FrameworkWindow() {}

void FrameworkWindow::setModuleInfo(const QList<ModuleInfo>& infoList) { m_impl->moduleInfos = infoList; }

void FrameworkWindow::setMenuInfo(const QList<MenuInfo>& menuInfos) { m_impl->menuInfos = menuInfos; }

void FrameworkWindow::init()
{
    resize(qApp->desktop()->maximumSize());

    install();

    for (const auto& menuInfo : m_impl->menuInfos)
    {
        if (menuInfo.subMenus.isEmpty())
        {
            auto action = new QAction(menuInfo.name, nullptr);
            connect(action, &QAction::triggered, this, [=]() { slotMenuActionClicked(menuInfo); });
            menuBar()->addAction(action);

            if (menuInfo.isDefaultTriggered)
            {
                m_impl->defaultTriggeredActions.append(action);
            }

            continue;
        }

        auto menu = new QMenu(menuInfo.name);
        createMenu(menuInfo.subMenus, menu);

        menuBar()->addMenu(menu);
    }
}

void FrameworkWindow::showEvent(QShowEvent* event)
{
    static bool isFirstShow = true;
    if (isFirstShow)
    {
        isFirstShow = false;
        for (auto action : m_impl->defaultTriggeredActions)
        {
            emit action->triggered(true);
        }
    }

    QMainWindow::showEvent(event);
}
void FrameworkWindow::closeEvent(QCloseEvent* event)
{
    if (0 != QMessageBox::information(this, "提示", "是否要退出本程序！！！！", "退出", "取消"))
    {
        event->ignore();
        return;
    }

    event->accept();
}

void FrameworkWindow::install()
{
    for (auto& moduleInfo : m_impl->moduleInfos)
    {
        if (!moduleInfo.use)
        {
            continue;
        }
        auto& moduleName = moduleInfo.name;
        auto moduleFullPath = PlatformConfigTools::plugPath(moduleName);
        /* 插件不存在 */
        if (!QFile::exists(moduleFullPath))
        {
            qWarning() << QString("插件不存在：%1").arg(moduleName);
            continue;
        }

        try
        {
            auto newBundles = m_impl->context.InstallBundles(moduleFullPath.toStdString());
            for (auto& newBundle : newBundles)
            {
                newBundle.Start();
            }
        }
        catch (const std::exception& ex)
        {
            qWarning() << QString("安装插件失败：%1，%2").arg(moduleName).arg(ex.what());
            continue;
        }
        catch (...)
        {
            qWarning() << QString("安装插件失败");
            continue;
        }
    }
}

void FrameworkWindow::createMenu(const QList<MenuInfo>& menuInfos, QMenu* parentMenu)
{
    for (auto& menuInfo : menuInfos)
    {
        if (menuInfo.subMenus.isEmpty())
        {
            auto action = new QAction(menuInfo.name, nullptr);
            connect(action, &QAction::triggered, this, [=]() { slotMenuActionClicked(menuInfo); });
            parentMenu->addAction(action);
        }
        else
        {
            auto menu = new QMenu(menuInfo.name);
            createMenu(menuInfo.subMenus, menu);
            parentMenu->addMenu(menu);
        }
    }
}

void FrameworkWindow::uninstallGuiServices(ServiceReferenceU serviceRef)
{
    auto guiService = m_impl->context.GetService<IGuiService>(serviceRef);

    if (guiService == nullptr)
    {
        return;
    }
    m_impl->serviceInfoMap.unstallService(guiService.get());
}

#include "ConfigMacroMessageDefine.h"
#include "ControlCmdResponseUnpacker.h"
#include "ControlResultReportUnpacker.h"
#include "CustomPacketMessageSerialize.h"
#include "DevProtocolSerialize.h"
#include "ExtensionStatusReportUnpacker.h"
#include "GlobalData.h"
#include "GroupParamSetPacker.h"
#include "INetMsg.h"
#include "PacketHandler.h"
#include "PlanRunMessageSerialize.h"
#include "ProcessControlCmdPacker.h"
#include "RedisHelper.h"
#include "ServiceHelper.h"
#include "StatusQueryCmdPacker.h"
#include "UnitParamSetPacker.h"

#include <QLabel>
#include <QPushButton>
#include <QTabWidget>
#include <QVBoxLayout>
void FrameworkWindow::packTest()
{
    auto vLayout = new QVBoxLayout(this);

    auto widget = new QWidget;
    widget->setLayout(vLayout);
    setCentralWidget(widget);

    PacketHandler::instance().appendPacker(new UnitParamSetPacker());
    PacketHandler::instance().appendPacker(new ProcessControlCmdPacker());
    //    PacketHandler::instance().appendPacker(new StatusQueryCmdPacker());
    PacketHandler::instance().appendPacker(new GroupParamSetPacker());

    PacketHandler::instance().appendUnpacker(new ControlCmdResponseUnpacker());
    PacketHandler::instance().appendUnpacker(new ControlResultReportUnpacker());
    PacketHandler::instance().appendUnpacker(new ExtensionStatusReportUnpacker());

    auto unitParamSettingBtn = new QPushButton("单元参数组包");
    vLayout->addWidget(unitParamSettingBtn);
    connect(unitParamSettingBtn, &QPushButton::clicked, this, [=]() {
        QByteArray packData;
        UnitParamSetMessage unitSetMsg;
        unitSetMsg.channelValidIdent = 0;
        unitSetMsg.mode = 0xffff;
        unitSetMsg.unitId = 0x1;

        QMap<QString, QVariant> paramMap;
        paramMap["TaskIndet_KA"] = "AAAAA";
        unitSetMsg.settingParamMap = paramMap;

        MessageAddress sourceAddr;
        sourceAddr.baseNumb = 0x26;
        sourceAddr.stationNumb = 0x42;
        sourceAddr.systemNumb = 0x4;
        sourceAddr.deviceNumb = 0x4;
        sourceAddr.extenNumb = 0x01;

        MessageAddress targetAddr = sourceAddr;

        Version version;
        version.mainVersion = 0x2;
        version.subVersionOne = 0x1;
        version.subVersionTwo = 0x3;

        PackMessage packMsg;
        packMsg.header.msgType = DevMsgType::UnitParameterSetCmd;
        packMsg.header.sourceAddr = sourceAddr;
        packMsg.header.targetAddr = targetAddr;
        packMsg.header.version = version;
        packMsg.unitParamSetMsg = unitSetMsg;

        QString erroMsg;
        if (!PacketHandler::instance().pack(packMsg, packData, erroMsg))
        {
            qWarning() << "单元参数组包失败";
        }
    });

    auto processCtrlCmdBtn = new QPushButton("过程控制命令组包");
    vLayout->addWidget(processCtrlCmdBtn);
    connect(processCtrlCmdBtn, &QPushButton::clicked, this, [=]() {
        QByteArray packData;
        ProcessControlCmdMessage controlCtrlCmdMsg;
        controlCtrlCmdMsg.mode = 0xFFFF;
        controlCtrlCmdMsg.cmdId = 8;

        MessageAddress sourceAddr;
        sourceAddr.baseNumb = 0x26;
        sourceAddr.stationNumb = 0x01;
        sourceAddr.systemNumb = 0x8;
        sourceAddr.deviceNumb = 0x1;
        sourceAddr.extenNumb = 0x01;

        MessageAddress targetAddr = sourceAddr;

        Version version;
        version.mainVersion = 0x2;
        version.subVersionOne = 0x1;
        version.subVersionTwo = 0x3;

        PackMessage packMsg;
        packMsg.header.msgType = DevMsgType::ProcessControlCmd;
        packMsg.header.sourceAddr = sourceAddr;
        packMsg.header.targetAddr = targetAddr;
        packMsg.header.version = version;
        packMsg.processCtrlCmdMsg = controlCtrlCmdMsg;

        QString erroMsg;
        PacketHandler::instance().pack(packMsg, packData, erroMsg);
        qDebug() << packData.toHex().toUpper();
    });

    auto groupParamCmdBtn = new QPushButton("组参数设置命令组包");
    vLayout->addWidget(groupParamCmdBtn);
    connect(groupParamCmdBtn, &QPushButton::clicked, this, [=]() {
        QByteArray packData;
        GroupParamSetMessage groupParamCmdMsg;
        groupParamCmdMsg.modeId = 0x4;

        UnitParamSetMessage unitMsg;
        unitMsg.unitId = 1;
        unitMsg.mode = 0x4;
        unitMsg.multiTargetParamMap[1]["Target_WorkRate"] = 2258;
        groupParamCmdMsg.unitParamSetMsgMap[1] = unitMsg;

        MessageAddress sourceAddr;
        sourceAddr.baseNumb = 0x26;
        sourceAddr.stationNumb = 0x01;
        sourceAddr.systemNumb = 0x4;
        sourceAddr.deviceNumb = 0x0;
        sourceAddr.extenNumb = 0x02;

        MessageAddress targetAddr = sourceAddr;

        Version version;
        version.mainVersion = 0x2;
        version.subVersionOne = 0x1;
        version.subVersionTwo = 0x3;

        PackMessage packMsg;
        packMsg.header.msgType = DevMsgType::GroupParamSetCmd;
        packMsg.header.sourceAddr = sourceAddr;
        packMsg.header.targetAddr = targetAddr;
        packMsg.header.version = version;
        packMsg.groupParamSetMsg = groupParamCmdMsg;

        QString erroMsg;
        PacketHandler::instance().pack(packMsg, packData, erroMsg);
    });

    auto ctrlCmdRespBtn = new QPushButton("控制命令响应");
    vLayout->addWidget(ctrlCmdRespBtn);
    connect(ctrlCmdRespBtn, &QPushButton::clicked, this, [=]() {
        QByteArray data = QByteArray::fromHex("0000000140244226000000010024422600f100001202000000002120cdf034080b00000001f0000001420000000001");

        UnpackMessage unpackMsg;
        PacketHandler::instance().unpack(data, unpackMsg);

        ControlCmdResponseMessage msg = unpackMsg.controlCmdRespMsg;

        qDebug() << "信息类型:" << DevMsgTypeHelper::toDescStr(msg.msgType) << "标识:" << msg.cmdId << "顺序号：" << msg.orderNum
                 << "控制结果:" << ControlCmdResponseTypeHelper::toDescStr(msg.result);
    });

    auto ctrlResultReportBtn = new QPushButton("控制结果上报");
    vLayout->addWidget(ctrlResultReportBtn);
    connect(ctrlResultReportBtn, &QPushButton::clicked, this, [=]() {
        QByteArray data = QByteArray::fromHex(
            "0000000160264226000000010026422601F1000000000000260521203F17CD2B06050000FC43050000006161612E64617400000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "00000000000000000000000000000000000000000000000000006262672E6461740000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000054656C6564617461436F6E7665727465722E65786500000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000059435F4B5032"
            "5F5B31313131313131315D5F5330315F5B3230323030333132313631315D2E64617400000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000B8B4BCFE206161612E64617400000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "000000000000000000000000000000000000000000000000000000000000");

        UnpackMessage unpackMsg;
        PacketHandler::instance().unpack(data, unpackMsg);

        ControlResultReportMessage msg = unpackMsg.controlResultReportMsg;

        // qDebug() << "原始数据：" << data.toHex();
        for (auto key : msg.paramMap.keys())
        {
            qDebug() << key << msg.paramMap.value(key).toString();
        }
    });

    auto extenStatusReportBtn = new QPushButton("分机状态上报");
    vLayout->addWidget(extenStatusReportBtn);
    connect(extenStatusReportBtn, &QPushButton::clicked, this, [=]() {
        QByteArray data = QByteArray::fromHex(
            "0000000381244226000000010024422604f100007901000000000000000000009b0b00000000fb0101020101018077c70e87ad4b00f9c97b0e9098bb5800000000706895"
            "1d00000000018077c70e05ae4b007bc97b0e000089000301fe01fb0202594a3031303130355f594a303130315f43435a465f4f505f5343534a5f4232303231303531335f"
            "3136353035305f3131333132335f36353533355f303432362e64617400000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "00000000000000000000000000000000000000c15752000000000028000000b8bd8f1d000000000228b6dd0c0000000000000000a90100006c6f63616c33303735000000"
            "000000000000000001f401000042343333340000000031000000000037010000640000007465737400000000000000000000000000000000545300000000000000000000"
            "000000000000000000000201fffffffffe02fb03010000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000"
            "01f4010000550000000000000000000000000000000000003900000035350000000000000000000000000000000000005453000000000000000000000000000000000000"
            "00000101fffffffffe03fb040100000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "000000000000000000000000000000000000000000000001000000000000000000000000000000000000000000000000000000000000000000000000ffffffffff420000"
            "000000000000000000000000ffffffffffffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000ffffffffffffffff"
            "fe04fb0501000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "0000000000000000000000000000000100000000000000000000000000000000000000000000000000000000000000000000000001ffffffff4200000000000000000000"
            "0000000000000000ffffffff00000000000000000000000000000000000000000000000000000000000000000000000000000000ffffff01fffffffffe05fb0602594a30"
            "313031035445535434330000000000000000000000000000a0b6dd0c00000000ae79b2030000000000000000000000000500000000000000000000000000000000000000"
            "000000000000000000000000000000000000000000000000000000000000000000000000005445535434310000000000000000000000000000a0b6dd0c00000000837eb2"
            "0300000000000000000000000005000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000"
            "00004c4f43414c000000000000000000000000000000a0b6dd0c00000000e17ab20300000000000000000000000005000000000000000000000000000000000000000000"
            "00000000000000000000000000000000000000000000000000000000000000000000005064ba3dffff0000a47b4600000000006071780000000000e866ba3dffff000080"
            "6cba3dffff0000886a46000000000090d2bb3dffff0000e8236e1fffff000028246e1fffff000030246e1f040000003047011cffff0000c8e3bb3dffff0000a064ba3dff"
            "ff0000a864ba3dffff000000000000000000000000ebbcffff000000000000ffff0000c864ba3dffff000000000000000000000033333400ff00008065ba3dffff0000e8"
            "64ba3dffff000000000000000000000035007400ff0000e0236e1fffff00000865ba3dffff00000000000000000000005300bcffff0000e8356e1fffff00002865ba3dff"
            "ff00000000000000000000006f63616c3330373500ba3dffff00004865ba3dffff0000090000000000000043485064ba3dffff0000a47b46000000000060717800000000"
            "00e866ba3dffff0000806cba3dffff0000886a46000000000090d2bb3dffff0000e8236e1fffff000028246e1fffff000030246e1f040000003047011cffff0000c8e3bb"
            "3dffff0000a064ba3dffff0000a864ba3dffff000000000000000000000000ebbcffff000000000000ffff0000c864ba3dffff000000000000000000000033333400ff00"
            "008065ba3dffff0000e864ba3dffff000000000000000000000035007400ff0000e0236e1fffff00000865ba3dffff00000000000000000000005300bcffff0000e8356e"
            "1fffff00002865ba3dffff00000000000000000000006f63616c3330373500ba3dffff00004865ba3dffff0000090000000000000043485064ba3dffff0000a47b460000"
            "0000006071780000000000e866ba3dffff0000806cba3dffff0000886a46000000000090d2bb3dffff0000e8236e1fffff000028246e1fffff000030246e1f0400000030"
            "47011cffff0000c8e3bb3dffff0000a064ba3dffff0000a864ba3dffff000000000000000000000000ebbcffff000000000000ffff0000c864ba3dffff00000000000000"
            "0000000033333400ff00008065ba3dffff0000e864ba3dffff000000000000000000000035007400ff0000e0236e1fffff00000865ba3dffff0000000000000000000000"
            "5300bcffff0000e8356e1fffff00002865ba3dffff00000000000000000000006f63616c3330373500ba3dffff00004865ba3dffff000009000000000000004348c0e03f"
            "1f00000000acb3c9df9b0000000100000000f401000000000000fe06fb070100000000000000000000000000000000000000000000000100000000f401000000000000fe"
            "07fb080100000000000000000000000000000000000000000000000100000000f401000000000000fe08fb09010000000000000000000000000000000000000000000000"
            "0100000000f401000000000000fe09");

        UnpackMessage unpackMsg;
        if (!PacketHandler::instance().unpack(data, unpackMsg))
        {
            qDebug() << "解析错误";
        }
    });

    auto redisPublishBtn = new QPushButton("redis 推送数据");
    vLayout->addWidget(redisPublishBtn);
    connect(redisPublishBtn, &QPushButton::clicked, this, [=]() {
        RedisHelper::getInstance().publish("some_chan", "31212131");
        qDebug() << "redis push data";
    });
}

void FrameworkWindow::slotMenuActionClicked(const MenuInfo& menuInfo)
{
    auto serviceRefs = m_impl->context.GetServiceReferences("");

    /* 1. 查找服务*/
    std::shared_ptr<IGuiService> curGuiService;
    for (auto serviceRef : serviceRefs)
    {
        /* 模块名一致 且 是gui服务 */
        if ((QString("[IGuiService]") == QString::fromStdString(serviceRef.GetProperty("objectclass").ToString())) &&
            (QString::fromStdString(serviceRef.GetBundle().GetSymbolicName()) == menuInfo.moduleName))
        {
            curGuiService = m_impl->context.GetService<IGuiService>(serviceRef);
            break;
        }
    }
    if (curGuiService == nullptr)
    {
        return;
    }
    /* 2 根据服务找和菜单名字找控widget  */
    /* 这里这么写是希望,失败就不更改原有数据 */
    auto containerWidget = m_impl->serviceInfoMap.getWidget(curGuiService.get(), menuInfo.name);

    /* 3 根据类型区分 */
    switch (menuInfo.widgetType)
    {
    case MenuWidgetType::Dock:  // dock窗口
    {
        /* 首次使用 */
        /* 这里没有原来的逻辑,因为qobject_cast也存在失败的可能就无法分辨是本来就是nullptr还是转换失败了 */
        if (containerWidget == nullptr)
        {
            auto tempWidget = curGuiService->createWidget(menuInfo.subWidgetName);
            if (tempWidget == nullptr)
            {
                QMessageBox::critical(this, QString("错误"), QString("加载当前界面失败"), "确认");
                return;
            }

            auto dockWidget = new QDockWidget(menuInfo.name, this);
            m_impl->serviceInfoMap.insertWidget(curGuiService.get(), menuInfo.name, dockWidget);
            dockWidget->setWidget(tempWidget);
            dockWidget->setFeatures(QDockWidget::DockWidgetMovable | QDockWidget::DockWidgetClosable);
            dockWidget->setAllowedAreas(Qt::AllDockWidgetAreas);
            addDockWidget(Qt::RightDockWidgetArea, dockWidget);
            containerWidget = dockWidget;
        }
        containerWidget->setVisible(!containerWidget->isVisible());
        return;
    }
    case MenuWidgetType::Dialog:  // dialog窗口
    {
        /* 这里没有原来的逻辑,因为qobject_cast也存在失败的可能就无法分辨是本来就是nullptr还是转换失败了 */
        if (containerWidget == nullptr)
        {
            auto tempWidget = curGuiService->createWidget(menuInfo.subWidgetName);
            if (tempWidget == nullptr)
            {
                QMessageBox::critical(this, QString("错误"), QString("加载当前界面失败"), "确认");
                return;
            }

            auto vLayout = new QVBoxLayout;
            vLayout->addWidget(tempWidget);

            containerWidget = new QDialog;
            containerWidget->setMinimumSize(1600, 910);

            containerWidget->setLayout(vLayout);
            containerWidget->setWindowTitle(menuInfo.name);
            containerWidget->setWindowFlags(Qt::Dialog | Qt::WindowCloseButtonHint | Qt::WindowMinimizeButtonHint |
                                            Qt::WindowMaximizeButtonHint);  // 只显示关闭按钮

            m_impl->serviceInfoMap.insertWidget(curGuiService.get(), menuInfo.name, containerWidget);
        }

        containerWidget->show();
        return;
    }
    case MenuWidgetType::UnknownType:
    {
        break;
    }
    }

    /* 到这里都是加载失败 */
    QMessageBox::critical(nullptr, QString("错误"), QString("菜单窗口类型配置错误"), "确认");
}
