#ifndef WIZARDLOAD_H
#define WIZARDLOAD_H

#include "PlatformDefine.h"
#include <QString>

enum class WizardResult
{
    Finish, /* 完成 */
    Error,  /* 向导加载错误 */
    Skip,   /* 跳过向导 */
    Quit,   /* 退出程序 */
};

class WizardLoad
{
public:
    WizardLoad();
    ~WizardLoad();
    WizardResult loadWizard(const PlatformConfigInfo& config); /* 加载向导 */
    /* 获取经过向导处理以后的配置数据,此数据loadWizard返回值不为Quit Error时间有效,否则数据是无效的 */
    PlatformConfigInfo platformConfigInfo() const { return m_info; }
    QString errMsg() const { return m_errMsg; }

private:
    PlatformConfigInfo m_info;
    QString m_errMsg;
};

#endif  // WIZARDLOAD_H
