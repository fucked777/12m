#ifndef PLATFROMDEFINE_H
#define PLATFROMDEFINE_H
#include <QList>
#include <QString>

/* 模块信息 */
struct ModuleInfo
{
    QString name;
    bool use{ true }; /* 是否使用 */
};

/* 菜单widget类型 */
enum class MenuWidgetType
{
    UnknownType,
    Dialog,
    Dock,
};

/* 菜单信息 */
struct MenuInfo
{
    QString name;
    QString moduleName;
    QString subWidgetName;
    QString pngSrc;
    MenuWidgetType widgetType;
    bool isDefaultTriggered{ false };

    QList<MenuInfo> subMenus;
};
class MenuInfoHelper
{
public:
    static MenuWidgetType fromStr(const QString&);
    static QString toStr(MenuWidgetType);
};

#endif  // PLATFROMDEFINE_H
