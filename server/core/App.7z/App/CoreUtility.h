#ifndef COREUTILITY_H
#define COREUTILITY_H
#include <QString>

struct PlatformConfigInfo;
class CoreUtility
{
public:
    /* 统一返回 /作为路径分隔符 且转换为绝对路径 */
    static QString absolutePathNativeSeparators(const QString& path);
    /* 将配置全局写入 */
    static void writeConfigToGlobal(const PlatformConfigInfo& info);
};

#endif  // COREUTILITY_H
