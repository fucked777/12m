#include "PlatfromDefine.h"

MenuWidgetType MenuInfoHelper::fromStr(const QString& raw)
{
    auto type = raw.toUpper();
    if (type == "DIALOG")
    {
        return MenuWidgetType::Dialog;
    }
    else if (type == "DOCK")
    {
        return MenuWidgetType::Dock;
    }
    return MenuWidgetType::UnknownType;
}
QString MenuInfoHelper::toStr(MenuWidgetType type)
{
    switch (type)
    {
    case MenuWidgetType::UnknownType:
    {
        break;
    }
    case MenuWidgetType::Dialog:
    {
        return "Dialog";
    }
    case MenuWidgetType::Dock:
    {
        return "Dock";
    }
    }
    return "Unknown";
}
