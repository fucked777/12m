﻿#ifndef RIBBONMAINWINDOW_H
#define RIBBONMAINWINDOW_H
#include "SARibbonMainWindow.h"

#include "CppMicroServicesUtility.h"
#include <QMainWindow>
#include <QMap>

class QDomElement;
class QAction;
class QMenu;
class QMenuBar;
class QMdiArea;
class SARibbonCategory;
class SARibbonContextCategory;
class QTextEdit;
class SARibbonPannel;

using namespace cppmicroservices;

class QMenu;

struct ModuleInfo;
struct MenuInfo;

enum class MenuWidgetType;

class RibbonMainWindow : public SARibbonMainWindow
{
    Q_OBJECT
public:
    RibbonMainWindow(cppmicroservices::BundleContext context, QWidget* parent = 0);
    ~RibbonMainWindow();

private:
private slots:
    void onShowContextCategory(bool on);

private:
private slots:
    void onMenuButtonPopupCheckableTest(bool b);
    void onInstantPopupCheckableTest(bool b);
    void onDelayedPopupCheckableTest(bool b);

    void onMenuButtonPopupCheckabletriggered(bool b);
    void onInstantPopupCheckabletriggered(bool b);
    void onDelayedPopupCheckabletriggered(bool b);

public:
    // 设置模块信息
    void setModuleInfo(const QList<ModuleInfo>&);
    // 设置菜单信息
    void setMenuInfo(const QList<MenuInfo>& menuInfos);
    // 初始化
    void init();

private:
    void install();
    // 创建菜单
    void createMenu(const QList<MenuInfo>& menuInfos, SARibbonPannel* pannel);

    void installGuiServices(ServiceReferenceU serviceRef);
    void uninstallGuiServices(ServiceReferenceU serviceRef);

signals:
    void signalInstallGuiServices(ServiceReferenceU service_ref);
    void signalUninstallGuiServices(ServiceReferenceU service_ref);

private slots:
    // 菜单点击
    void slotMenuActionClicked(const MenuInfo& menuInfo);

private:
    BundleContext mContext;

    ListenerToken mListenerToken;

    QList<MenuInfo> mMenuInfos;      // 菜单信息
    QList<ModuleInfo> mModuleInfos;  // 模块信息

    QMap<QString, QWidget*> mWidgetMap;

private:
    SARibbonContextCategory* m_contextCategory;

    QMdiArea* m_pMdiArea = nullptr;  //多文档视图
};

#endif  // RIBBONMAINWINDOW_H
