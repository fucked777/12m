#include "CoreUtility.h"
#include "CppMicroServicesUtility.h"
#include "FrameworkWindow.h"
#include "IWizard.h"
#include "MenuConfigLoad.h"
#include "ModulConfigLoad.h"
#include "PlatformConfigLoad.h"
#include "PlatformConfigTools.h"
//#include "RibbonMainWindow.h"
#include "SingleModuleLoad.h"
#include "WizardLoad.h"
#include "qtsingleapplication.h"
#include <QApplication>
#include <QDebug>
#include <QDir>
#include <QMessageBox>

/*
 * 0x01 载入配置文件,必须在QtSingleApplication之前加载
 * 0x02 载入向导界面,可以没有
 * 0x03 模块加载
 * 0x03 载入启动界面,可以没有
 * 0x04 载入主界面,可以没有
 * 0x05 模块卸载
 * 0x05 载入结束界面,可以没有
 */
using namespace cppmicroservices;

static QList<ModuleInfo> loadModuleConfig();
static QList<MenuInfo> loadMenuConfig();
int main(int argc, char* argv[])
{
    PlatformConfigInfo platformConfigInfo; /* 平台的配置信息 */
    /* 0x01 载入配置文件,必须在QtSingleApplication之前加载 */
    {
        PlatformConfigLoad config;
        if (!config.load())
        {
            QApplication application(argc, argv);
            QMessageBox::information(nullptr, "平台配置加载错误", config.errMsg());
            return 1;
        }
        platformConfigInfo = config.platformConfigInfo();
    }
    /* 0x01 End */

    QtSingleApplication singleApplication(platformConfigInfo.mainInfo.instanceID, argc, argv);
    if (singleApplication.isRunning())
    {
        QMessageBox::information(nullptr, "提示", "当前程序已运行");
        return 0;
    }

    /* 0x02 载入向导界面,可以没有,即使向导错误也可以使用默认的配置运行 */
    {
        WizardLoad wizardLoad;
        auto result = wizardLoad.loadWizard(platformConfigInfo);
        switch (result)
        {
        case WizardResult::Finish: /* 完成 */
        {
            platformConfigInfo = wizardLoad.platformConfigInfo();
            break;
        }
        case WizardResult::Skip: /* 跳过向导 */
        {
            break;
        }
        case WizardResult::Error: /* 向导加载错误 */
        {
            QMessageBox::warning(nullptr, "加载向导错误", wizardLoad.errMsg());
            break;
        }
        case WizardResult::Quit: /* 退出程序 */
        {
            return 0;
        }
        }

        /* 写入全局配置数据 */
        CoreUtility::writeConfigToGlobal(platformConfigInfo);
    }
    /* 0x02 End */

    /* 到这里是所有的配置数据已经加载完成了 */
    /* 0x03 模块加载 */
    /* 0x03 载入启动界面,可以没有*/
    /* 0x03 End */

    /* 0x04 载入主界面,可以没有 */
    /* 0x04 End */

    /* 0x05 载入结束界面,可以没有 */
    /* 0x05 模块卸载 */
    /* 0x05 End */

    FrameworkFactory factory;
    auto framework = factory.NewFramework();

    try
    {
        /* 无法初始化会抛异常 */
        framework.Init();
        /*
         * 未初始化抛异常
         * 无法启动抛异常
         * 已卸载抛异常
         */
        framework.Start();
    }
    catch (const std::exception& e)
    {
        QMessageBox::information(nullptr, "服务初始化错误", QString::fromStdString(e.what()));
        return 1;
    }

    /*
     * 未初始化会抛异常
     */
    auto context = framework.GetBundleContext();
    if (!context)
    {
        QMessageBox::information(nullptr, "服务初始化错误", "无效的Context");
        return 1;
    }

    FrameworkWindow f(context);
    f.setModuleInfo(loadModuleConfig());
    f.setMenuInfo(loadMenuConfig());
    f.setWindowTitle(platformConfigInfo.mainInfo.name);
    f.init();
    f.showMaximized();

    //    RibbonMainWindow r(context);
    //    r.setModuleInfo(loadModuleConfig());
    //    r.setMenuInfo(loadMenuConfig());
    //    r.setWindowTitle(config.platformMainConfig().name);
    //    r.init();
    //    r.show();

    auto ret = singleApplication.exec();

    auto bundles = context.GetBundles();
    for (auto& item : bundles)
    {
        item.Stop();
    }
    return ret;
}

/**********************************************************************************************/
/**********************************************************************************************/
/**********************************************************************************************/
/**********************************************************************************************/
/**********************************************************************************************/
/**********************************************************************************************/
static QList<ModuleInfo> loadModuleConfig()
{
    /* 加载模块信息 */
    ModulConfigLoad modulConfigLoad;
    if (!modulConfigLoad.load())
    {
        QMessageBox::critical(nullptr, "模块配置载入失败", modulConfigLoad.errMsg());
        return {};
    }
    return modulConfigLoad.moduleList();
}
static QList<MenuInfo> loadMenuConfig()
{
    /* 加载菜单信息 */
    MenuConfigLoad menuConfigLoad;
    if (!menuConfigLoad.load())
    {
        QMessageBox::critical(nullptr, "菜单配置载入失败", menuConfigLoad.errMsg());
        return {};
    }
    return menuConfigLoad.menuList();
}
