#include "CoreUtility.h"
#include "PlatformConfigTools.h"
#include "PlatformInterface.h"
#include <QDir>
#include <QRegularExpression>

QString CoreUtility::absolutePathNativeSeparators(const QString& path)
{
    /* 先全部变成/  然后替换 */
    auto tempPath = QDir::fromNativeSeparators(path);
    tempPath.replace(QRegularExpression("/+"), "/");
    QDir tempDir(tempPath);
    return tempDir.absolutePath();
}

void CoreUtility::writeConfigToGlobal(const PlatformConfigInfo& bak)
{
    auto info = bak;
    /* 这里要处理一下路径 */
    auto& mainConfig = info.mainInfo;
    mainConfig.businessConfigDir = CoreUtility::absolutePathNativeSeparators(mainConfig.businessConfigDir);
    mainConfig.platformConfigDir = CoreUtility::absolutePathNativeSeparators(mainConfig.platformConfigDir);
    mainConfig.shareConfigDir = CoreUtility::absolutePathNativeSeparators(mainConfig.shareConfigDir);

    PlatformConfigTools::setPlatformConfigInfo(info);
}
