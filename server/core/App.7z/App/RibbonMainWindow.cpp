﻿#include "RibbonMainWindow.h"

#include "PlatformInterface.h"
#include "PlatfromDefine.h"
#include "QColor"
#include "SARibbonBar.h"
#include "SARibbonButtonGroupWidget.h"
#include "SARibbonCategory.h"
#include "SARibbonCheckBox.h"
#include "SARibbonComboBox.h"
#include "SARibbonGallery.h"
#include "SARibbonLineEdit.h"
#include "SARibbonMenu.h"
#include "SARibbonPannel.h"
#include "SARibbonQuickAccessBar.h"
#include "SARibbonToolButton.h"
#include "CppMicroServicesUtility.h"
#include <QAbstractButton>
#include <QAction>
#include <QApplication>
#include <QCloseEvent>
#include <QCoreApplication>
#include <QDataStream>
#include <QDebug>
#include <QDesktopWidget>
#include <QDir>
#include <QDockWidget>
#include <QDomDocument>
#include <QElapsedTimer>
#include <QFile>
#include <QLabel>
#include <QMdiArea>
#include <QMdiSubWindow>
#include <QMenu>
#include <QMenuBar>
#include <QMessageBox>
#include <QPushButton>
#include <QStatusBar>
#include <QTextEdit>
#include <QVBoxLayout>

extern uint g_uiRemoteClose;
void WriteLog(QString strLog, unsigned char ucWarningLevel = 1);
RibbonMainWindow::RibbonMainWindow(cppmicroservices::BundleContext context, QWidget* parent)
    : SARibbonMainWindow(parent)
    , mContext(context)

{
    SARibbonBar* ribbon = ribbonBar();

    ribbonBar()->setRibbonStyle(SARibbonBar::WpsLiteStyle);
    QFont f = ribbon->font();
    f.setFamily("微软雅黑");
    ribbon->setFont(f);

    ribbon->applicationButton()->hide();

    m_pMdiArea = new QMdiArea(this);
    setCentralWidget(m_pMdiArea);
    qRegisterMetaType<ServiceReferenceU>("ServiceReferenceU");
    mListenerToken = mContext.AddServiceListener([=](const ServiceEvent& event) {
        std::string objectClass = ref_any_cast<std::vector<std::string>>(event.GetServiceReference().GetProperty(Constants::OBJECTCLASS)).front();

        if (event.GetType() == ServiceEvent::SERVICE_REGISTERED)
        {
            qDebug() << "Ex1: Service of type " << QString::fromStdString(objectClass) << " registered.";
            signalInstallGuiServices(event.GetServiceReference());
        }
        else if (event.GetType() == ServiceEvent::SERVICE_UNREGISTERING)
        {
            qDebug() << "Ex1: Service of type " << QString::fromStdString(objectClass) << " unregistered.";

            signalUninstallGuiServices(event.GetServiceReference());
        }
        else if (event.GetType() == ServiceEvent::SERVICE_MODIFIED)
        {
            qDebug() << "Ex1: Service of type " << QString::fromStdString(objectClass) << " modified.";
            signalUninstallGuiServices(event.GetServiceReference());
            signalInstallGuiServices(event.GetServiceReference());
        }
    });
    connect(this, &RibbonMainWindow::signalUninstallGuiServices, this, &RibbonMainWindow::uninstallGuiServices, Qt::QueuedConnection);
    connect(this, &RibbonMainWindow::signalInstallGuiServices, this, &RibbonMainWindow::installGuiServices, Qt::QueuedConnection);
}

RibbonMainWindow::~RibbonMainWindow() {}

void RibbonMainWindow::setModuleInfo(const QList<ModuleInfo>& infoList) { mModuleInfos = infoList; }
void RibbonMainWindow::setMenuInfo(const QList<MenuInfo>& menuInfos) { mMenuInfos = menuInfos; }
void RibbonMainWindow::init()
{
    this->resize(600, 600);

    install();
    for (const auto& menuInfo : mMenuInfos)
    {
        if (menuInfo.subMenus.isEmpty())
        {
            auto action = new QAction(menuInfo.name);
            connect(action, &QAction::triggered, this, [=]() { slotMenuActionClicked(menuInfo); });
            menuBar()->addAction(action);
            continue;
        }
        SARibbonBar* ribbon = ribbonBar();
        SARibbonCategory* categoryMain = ribbon->addCategoryPage(menuInfo.name);
        // auto menu = new QMenu(menuInfo.name);
        // SARibbonPannel *pannel = categoryMain->addPannel(QStringLiteral("Panel 1"));
        SARibbonPannel* panne2 = categoryMain->addPannel(menuInfo.name);
        createMenu(menuInfo.subMenus, panne2);

        //        menuBar()->addMenu(menu);
    }
}

void RibbonMainWindow::install()
{
    for (auto& moduleInfo : mModuleInfos)
    {
        if (!moduleInfo.use)
        {
            continue;
        }
        auto& moduleName = moduleInfo.name;
        auto moduleFullPath = PlatformConfigTools::plugPath(moduleName);
        /* 插件不存在 */
        if (!QFile::exists(moduleFullPath))
        {
            qWarning() << QString("插件不存在：%1").arg(moduleName);
            continue;
        }

        try
        {
            auto newBundles = mContext.InstallBundles(moduleFullPath.toStdString());
            for (auto& newBundle : newBundles)
            {
                newBundle.Start();
            }
        }
        catch (const std::exception& ex)
        {
            qWarning() << QString("安装插件失败：%1，%2").arg(moduleName).arg(ex.what());
            continue;
        }
        catch (...)
        {
            qWarning() << QString("安装插件失败");
            continue;
        }
    }
}

void RibbonMainWindow::createMenu(const QList<MenuInfo>& menuInfos, SARibbonPannel* pannel)
{
    for (auto& menuInfo : menuInfos)
    {
        if (menuInfo.subMenus.isEmpty())
        {
            auto action = new QAction(menuInfo.name);
            if (!menuInfo.pngSrc.isEmpty())
            {
                auto icon = QIcon(QPixmap(menuInfo.pngSrc).scaled(75, 75));
                action->setIcon(icon);
            }
            connect(action, &QAction::triggered, this, [=]() { slotMenuActionClicked(menuInfo); });
            auto btn = pannel->addLargeAction(action);
            btn->setFixedHeight(78);
            pannel->addLargeAction(action);
        }
        else
        {
            auto action = new QAction(menuInfo.name);
            if (!menuInfo.pngSrc.isEmpty())
            {
                auto icon = QIcon(QPixmap(menuInfo.pngSrc).scaled(75, 75));
                action->setIcon(icon);
            }
            connect(action, &QAction::triggered, this, [=]() { slotMenuActionClicked(menuInfo); });
            auto btn = pannel->addLargeAction(action);
            btn->setFixedHeight(78);
            pannel->addLargeAction(action);
        }
    }
}

void RibbonMainWindow::installGuiServices(ServiceReferenceU serviceRef)
{
    if (QString("[IGuiService]") == serviceRef.GetProperty("objectclass").ToString().c_str())
    {
        auto guiService = mContext.GetService<IGuiService>(serviceRef).get();
        if (guiService != nullptr)
        {
            // guiService->createWidget(this);
        }
    }
}

void RibbonMainWindow::uninstallGuiServices(ServiceReferenceU serviceRef)
{
    auto guiService = mContext.GetService<IGuiService>(serviceRef);

    if (guiService != nullptr)
    {
        auto widget = guiService->getWidget();
        if (widget != nullptr)
        {
            widget->deleteLater();
        }
    }
}

void RibbonMainWindow::slotMenuActionClicked(const MenuInfo& menuInfo)
{
    auto serviceRefs = mContext.GetServiceReferences("");
    for (auto serviceRef : serviceRefs)
    {
        if (QString("[IGuiService]") == serviceRef.GetProperty("objectclass").ToString().c_str())
        {
            auto guiService = mContext.GetService<IGuiService>(serviceRef).get();
            if (guiService != nullptr && QString(serviceRef.GetBundle().GetSymbolicName().c_str()) == menuInfo.moduleName)
            {
                QWidget* widget;
                if (menuInfo.subWidgetName.isEmpty())
                {
                    widget = guiService->createWidget();
                    if (widget == nullptr)
                    {
                        QMessageBox::critical(nullptr, QString("错误"), QString("打开失败"), QMessageBox::Ok);
                        return;
                    }
                }
                else
                {
                    widget = guiService->createWidget(menuInfo.subWidgetName);
                    if (widget == nullptr)
                    {
                        QMessageBox::critical(nullptr, QString("错误"), QString("打开失败"), QMessageBox::Ok);
                        return;
                    }
                }

                auto containerWidget = mWidgetMap[menuInfo.name];

                switch (menuInfo.widgetType)
                {
                case MenuWidgetType::Dock:  // dock窗口
                {
                    auto dockWidget = qobject_cast<QDockWidget*>(containerWidget);
                    if (dockWidget == nullptr)
                    {
                        dockWidget = new QDockWidget(menuInfo.name, this);
                        mWidgetMap[menuInfo.name] = dockWidget;
                    }

                    dockWidget->setFeatures(QDockWidget::DockWidgetMovable);
                    dockWidget->setAllowedAreas(Qt::AllDockWidgetAreas);
                    addDockWidget(Qt::RightDockWidgetArea, dockWidget);
                    dockWidget->setWidget(widget);
                }
                    return;
                case MenuWidgetType::Dialog:  // dialog窗口
                {
                    auto dialog = qobject_cast<QDialog*>(containerWidget);
                    if (dialog == nullptr)
                    {
                        auto vLayout = new QVBoxLayout;
                        vLayout->addWidget(widget);

                        dialog = new QDialog(this);
                        dialog->setFixedWidth(1536);
                        dialog->setFixedHeight(864);

                        dialog->setLayout(vLayout);
                        dialog->setWindowTitle(menuInfo.name);
                        dialog->setWindowFlags(Qt::Dialog | Qt::WindowCloseButtonHint);  //只显示关闭按钮

                        mWidgetMap[menuInfo.name] = dialog;
                    }

                    dialog->open();
                }
                    return;
                default:
                {
                    QMessageBox::critical(nullptr, QString("错误"), QString("菜单窗口类型配置错误"), QMessageBox::Ok);
                    return;
                };
                }
            }
        }
    }
}

void RibbonMainWindow::onShowContextCategory(bool on) { ribbonBar()->setContextCategoryVisible(m_contextCategory, on); }

void RibbonMainWindow::onMenuButtonPopupCheckableTest(bool b) {}

void RibbonMainWindow::onInstantPopupCheckableTest(bool b) {}

void RibbonMainWindow::onDelayedPopupCheckableTest(bool b) {}

void RibbonMainWindow::onMenuButtonPopupCheckabletriggered(bool b) {}

void RibbonMainWindow::onInstantPopupCheckabletriggered(bool b) {}

void RibbonMainWindow::onDelayedPopupCheckabletriggered(bool b) {}
