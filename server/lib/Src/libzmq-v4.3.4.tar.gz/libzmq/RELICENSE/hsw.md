# Permission to Relicense under MPLv2 or any other OSI approved license chosen by the current ZeroMQ BDFL

This is a statement by Christopher Hall that grants permission to
relicense its copyrights in the libzmq C++ library (ZeroMQ) under the
Mozilla Public License v2 (MPLv2) or any other Open Source Initiative
approved license chosen by the current ZeroMQ BDFL (Benevolent
Dictator for Life).

A portion of the commits made by the Github handle "hxw", with commit
author "Christopher Hall <hsw@ms2.hinet.net>", are copyright of
Christopher Hall.  This document hereby grants the libzmq project team
to relicense libzmq, including all past, present and future
contributions of the author listed above.

Christopher Hall
2019/08/07
