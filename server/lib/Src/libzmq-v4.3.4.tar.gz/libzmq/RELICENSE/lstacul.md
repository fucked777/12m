# Permission to Relicense under MPLv2

This is a statement by Laurent Stacul
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "stac47", with
commit author "Laurent Stacul <laurent.stacul@gmail.com>", are copyright of
Laurent Stacul .
This document hereby grants the libzmq project team to relicense libzmq, 
including all past, present and future contributions of the author listed above.

Laurent Stacul
2020/02/21
