# Permission to Relicense under MPLv2

This is a statement by Rosen Penev
that grants permission to relicense its copyrights in the libzmq C++
library (ZeroMQ) under the Mozilla Public License v2 (MPLv2).

A portion of the commits made by the Github handle "flub", with
commit author "Rosen Penev <rosenp@gmail.com>", are copyright of
Rosen Penev .
This document hereby grants the libzmq project team to relicense libzmq,
including all past, present and future contributions of the author listed above.

Rosen Penev
2019/04/19
