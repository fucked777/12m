#include <regex>
int main()
{
  auto regex_iter_end = std::sregex_iterator();
  (void)regex_iter_end;
  return 0;
}
