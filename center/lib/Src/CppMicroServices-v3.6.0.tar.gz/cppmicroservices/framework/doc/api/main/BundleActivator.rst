BundleActivator
---------------

.. doxygenstruct:: cppmicroservices::BundleActivator
