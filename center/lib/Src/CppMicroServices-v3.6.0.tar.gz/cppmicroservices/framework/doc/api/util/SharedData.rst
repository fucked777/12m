SharedData
----------

.. doxygengroup:: gr_shareddata
   :content-only:
