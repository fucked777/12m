GetBundleContext
----------------

.. doxygenfunction:: cppmicroservices::GetBundleContext
