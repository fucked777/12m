BundleContext
-------------

.. doxygenclass:: cppmicroservices::BundleContext
