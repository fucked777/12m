ShrinkableMap
-------------

.. doxygenclass:: cppmicroservices::ShrinkableMap
