LDAPFilter
----------

.. doxygengroup:: gr_ldap
   :content-only:
