Constants
---------

.. doxygennamespace:: cppmicroservices::Constants
