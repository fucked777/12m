PrototypeServiceFactory
-----------------------

.. doxygenstruct:: cppmicroservices::PrototypeServiceFactory
