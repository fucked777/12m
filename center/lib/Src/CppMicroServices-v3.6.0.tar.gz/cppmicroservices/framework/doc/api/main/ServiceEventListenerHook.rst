ServiceEventListenerHook
------------------------

.. doxygenstruct:: cppmicroservices::ServiceEventListenerHook
