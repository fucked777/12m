#include "TaskProcessControlWidget.h"
#include "ui_TaskProcessControlWidget.h"

#include "ConfigMacroXmlWorkModeDefine.h"
#include "CustomPacketMessageSerialize.h"
#include "ExtendedConfig.h"
#include "GlobalData.h"
#include "HP.h"
#include "HPCmd.h"
#include "MessagePublish.h"
#include "PlanRunMessageSerialize.h"
#include "SatelliteManagementSerialize.h"
#include "SystemCaptureProcessControl.h"
#include "SystemWorkMode.h"
#include "WorkModeXMLReader.h"

#include <QComboBox>
#include <QMessageBox>
#include <QPaintEvent>
#include <QPainter>
#include <QTreeWidget>
#include <QTreeWidgetItem>

TaskProcessControlWidget::TaskProcessControlWidget(QWidget* parent)
    : QDialog(parent)
    , ui(new Ui::TaskProcessControlWidget)
    , m_systemCaptureProcessControl(new SystemCaptureProcessControl(this))
{
    ui->setupUi(this);

    // 读取工作模式配置文件
    WorkModeXMLReader reader;
    mWorkSystem = reader.getWorkSystem();

    initUI();
    // 初始化快捷控制区域的工作模式、任务代号、点频等控件
    initQuickControlUI();
    // 初始化手动控制区域的工作模式、任务代号、点频等控件
    initManualControlUI();

    initSlot();

    ui->kpRB->setVisible(false);
    ui->dtRB->setVisible(false);
    ui->kpRB->setChecked(1);

    m_CurProject = ExtendedConfig::curProjectID();
}

TaskProcessControlWidget::~TaskProcessControlWidget() { delete ui; }

void TaskProcessControlWidget::paintEvent(QPaintEvent* event)
{
    QStyleOption opt;
    opt.init(this);
    QPainter p(this);
    style()->drawPrimitive(QStyle::PE_Widget, &opt, &p, this);
    event->accept();
}

void TaskProcessControlWidget::showEvent(QShowEvent* event)
{
    Q_UNUSED(event);
    slotRefreshData();
}

void TaskProcessControlWidget::initUI()
{
    auto systemCaptureProcessControlGroupBox = new QGroupBox("系统捕获流程控制");
    systemCaptureProcessControlGroupBox->setLayout(new QHBoxLayout);
    systemCaptureProcessControlGroupBox->layout()->addWidget(m_systemCaptureProcessControl);

    ui->scrollAreaWidgetContents->layout()->addWidget(systemCaptureProcessControlGroupBox);

    // 隐藏校零
    ui->xl_btn->setVisible(false);
    // 隐藏设备组合号下的全部内容
    ui->groupBox_3->setHidden(true);

    connect(ui->controlTabWidget, &QTabWidget::currentChanged, this, [=](int index) {
        if (index == 0)
        {
            m_systemCaptureProcessControl->setCurModeComBox(ui->ckWorkModeCombo);
        }
        else
        {
            if (ui->ckTabWidget->currentIndex() == 0)
            {
                m_systemCaptureProcessControl->setCurModeComBox(ui->ckWorkModeCombo);
            }
            else
            {
                m_systemCaptureProcessControl->setCurModeComBox(ui->ckWorkModeCombo_2);
            }
        }
    });

    connect(ui->ckTabWidget, &QTabWidget::currentChanged, this, [=](int index) {
        if (index == 0)
        {
            m_systemCaptureProcessControl->setCurModeComBox(ui->ckWorkModeCombo);
        }
        else
        {
            m_systemCaptureProcessControl->setCurModeComBox(ui->ckWorkModeCombo_2);
        }
    });
    m_systemCaptureProcessControl->setCurModeComBox(ui->ckWorkModeCombo);

    m_sHP = new HP;
    m_sHP->setType(HP::SCK);
    connect(m_sHP, &HP::signalsCmdDeviceJson, this, &TaskProcessControlWidget::signalsCmdDeviceJson);
    connect(m_sHP, &HP::signalsUnitDeviceJson, this, &TaskProcessControlWidget::signalsUnitDeviceJson);
    m_kaSCHP = new HP;
    m_kaSCHP->setType(HP::KaSC);
    connect(m_kaSCHP, &HP::signalsCmdDeviceJson, this, &TaskProcessControlWidget::signalsCmdDeviceJson);
    connect(m_kaSCHP, &HP::signalsUnitDeviceJson, this, &TaskProcessControlWidget::signalsUnitDeviceJson);
    m_kaCKHP = new HP;
    m_kaCKHP->setType(HP::KaCK);
    connect(m_kaCKHP, &HP::signalsCmdDeviceJson, this, &TaskProcessControlWidget::signalsCmdDeviceJson);
    connect(m_kaCKHP, &HP::signalsUnitDeviceJson, this, &TaskProcessControlWidget::signalsUnitDeviceJson);

    ui->scrollArea_2->setMinimumHeight(180);
}

void TaskProcessControlWidget::initQuickControlUI()
{
    // 添加快捷控制的测控工作模式
    ui->ckWorkModeCombo->addItem("无", NotDefine);
    for (auto item : mWorkSystem.ckCommands)
    {
        ui->ckWorkModeCombo->addItem(item.desc, item.id);
    }

    ui->ckWorkModeCombo_2->addItem("无", NotDefine);
    for (auto item : mWorkSystem.ckCommands)
    {
        ui->ckWorkModeCombo_2->addItem(item.desc, item.id);
    }

    // 添加快捷控制的数传工作模式
    ui->scWorkModeCombo->addItem("无", NotDefine);
    for (auto item : mWorkSystem.dtCommands)
    {
        ui->scWorkModeCombo->addItem(item.desc, item.id);
    }

    // 添加链路主备选择
    mMasterSlaveLinkBtnGroup.addButton(ui->masterRadioButton, static_cast<int>(MasterSlave::Master));
    mMasterSlaveLinkBtnGroup.addButton(ui->slaveRadioButton, static_cast<int>(MasterSlave::Slave));
    ui->masterRadioButton->setChecked(true);

    // 测控第一个tab
    ui->ckTargetRadioBtn2->setEnabled(false);
    ui->ckTargetRadioBtn3->setEnabled(false);
    ui->ckTargetRadioBtn4->setEnabled(false);

    ui->ckPointFreqCombo2->setEnabled(false);

    ui->ckTaskCodeCombo3->setEnabled(false);
    ui->ckPointFreqCombo3->setEnabled(false);
    ui->ckTaskCodeCombo2->setEnabled(false);

    ui->ckTaskCodeCombo4->setEnabled(false);
    ui->ckPointFreqCombo4->setEnabled(false);

    mCkTargetNoBtnGroup.addButton(ui->ckTargetRadioBtn1, 1);
    mCkTargetNoBtnGroup.addButton(ui->ckTargetRadioBtn2, 2);
    mCkTargetNoBtnGroup.addButton(ui->ckTargetRadioBtn3, 3);
    mCkTargetNoBtnGroup.addButton(ui->ckTargetRadioBtn4, 4);

    // 测控第二个tab
    ui->ckTargetRadioBtn2_2->setEnabled(false);
    ui->ckTargetRadioBtn3_2->setEnabled(false);
    ui->ckTargetRadioBtn4_2->setEnabled(false);

    ui->ckPointFreqCombo2_2->setEnabled(false);

    ui->ckTaskCodeCombo3_2->setEnabled(false);
    ui->ckPointFreqCombo3_2->setEnabled(false);
    ui->ckTaskCodeCombo2_2->setEnabled(false);

    ui->ckTaskCodeCombo4_2->setEnabled(false);
    ui->ckPointFreqCombo4_2->setEnabled(false);

    mCkTargetNoBtnGroup2.addButton(ui->ckTargetRadioBtn1_2, 1);
    mCkTargetNoBtnGroup2.addButton(ui->ckTargetRadioBtn2_2, 2);
    mCkTargetNoBtnGroup2.addButton(ui->ckTargetRadioBtn3_2, 3);
    mCkTargetNoBtnGroup2.addButton(ui->ckTargetRadioBtn4_2, 4);

    m_ckCombox[1] = ui->ckTaskCodeCombo1;
    m_ckCombox[2] = ui->ckTaskCodeCombo2;
    m_ckCombox[3] = ui->ckTaskCodeCombo3;
    m_ckCombox[4] = ui->ckTaskCodeCombo4;

    mSCTargetNoBtnGroup.addButton(ui->scTargetRadioBtn1, 1);
    mSCTargetNoBtnGroup.addButton(ui->scTargetRadioBtn2, 2);

    m_scCombox[1] = ui->scTaskCodeCombo1;
    m_scCombox[2] = ui->scTaskCodeCombo2;
}

void TaskProcessControlWidget::initManualControlUI()
{
    // 添加手动控制的工作模式
    ui->sdWorkModeCombo->addItem("无", NotDefine);
    for (auto item : mWorkSystem.ckCommands)
    {
        ui->sdWorkModeCombo->addItem(item.desc, item.id);
    }
    for (auto item : mWorkSystem.dtCommands)
    {
        ui->sdWorkModeCombo->addItem(item.desc, item.id);
    }

    mSDTargetNoBtnGroup.addButton(ui->sdTargetRadioBtn1, 1);
    mSDTargetNoBtnGroup.addButton(ui->sdTargetRadioBtn2, 2);
    mSDTargetNoBtnGroup.addButton(ui->sdTargetRadioBtn3, 3);
    mSDTargetNoBtnGroup.addButton(ui->sdTargetRadioBtn4, 4);

    m_sdCombox[1] = ui->sdTaskCodeCombo1;
    m_sdCombox[2] = ui->sdTaskCodeCombo2;
    m_sdCombox[3] = ui->sdTaskCodeCombo3;
    m_sdCombox[4] = ui->sdTaskCodeCombo4;

    auto widget = new QWidget();
    mDeviceWidgetMap.insert(NotDefine, widget);
    ui->deviceStackedWidget->addWidget(widget);

    // 从配置文件中读取配置，初始化界面
    ConfigMacroWorkModeList configMacroWorkModeList;
    GlobalData::getConfigMacroWorkModeData(configMacroWorkModeList);

    for (int index = 0; index < configMacroWorkModeList.size(); ++index)
    {
        auto configMacroWorkMode = configMacroWorkModeList.at(index);

        auto treeWidget = new QTreeWidget(this);
        treeWidget->setHidden(true);
        treeWidget->setColumnCount(2);
        treeWidget->setColumnWidth(0, 150);
        treeWidget->setColumnWidth(1, 150);
        treeWidget->setHeaderLabels(QStringList() << QString("名称") << QString("值"));

        for (auto item : configMacroWorkMode.items)
        {
            auto treeWidgetItem = new QTreeWidgetItem;

            treeWidgetItem->setText(0, item.desc);
            treeWidget->addTopLevelItem(treeWidgetItem);

            auto comboBox = new QComboBox(this);
            for (auto enumEntry : item.enums)
            {
                comboBox->addItem(enumEntry.desc, enumEntry.value);
                comboBox->setProperty("Item", QVariant::fromValue<Item>(item));
            }
            treeWidget->setItemWidget(treeWidgetItem, 1, comboBox);
        }

        ui->deviceStackedWidget->addWidget(treeWidget);
        mDeviceWidgetMap.insert(configMacroWorkMode.workMode, treeWidget);
    }
}

void TaskProcessControlWidget::initSlot()
{
    // 刷新数据
    connect(ui->refreshBtn, &QPushButton::clicked, this, &TaskProcessControlWidget::slotRefreshData);

    // 快捷控制界面测控模式改变时
    connect(ui->ckWorkModeCombo, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            &TaskProcessControlWidget::slotCKWorkModeChanged);

    connect(ui->ckWorkModeCombo_2, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            &TaskProcessControlWidget::slotCKWorkModeChanged2);

    // 快捷控制界面测控模式改变时,是否显示扩频和数传单选按钮
    connect(ui->ckWorkModeCombo, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            &TaskProcessControlWidget::slotIsShowRadioBtn);
    // 快捷控制界面数传模式改变时
    connect(ui->scWorkModeCombo, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            &TaskProcessControlWidget::slotSCWorkModeChanged);

    // 手动控制界面工作模式改变
    connect(ui->sdWorkModeCombo, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            &TaskProcessControlWidget::slotWorkModeChanged);
    // 手动控制界面工作模式改变,是否显示扩频和数传单选按钮
    connect(ui->sdWorkModeCombo, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            &TaskProcessControlWidget::slotIsShowRadioBtn);
    // 4424中，手动控制界面高速数传模式中的任务代号改变
    connect(ui->sdTaskCodeCombo1, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            &TaskProcessControlWidget::slotGSTaskCodeComboChanged);
    connect(ui->sdTaskCodeCombo2, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            &TaskProcessControlWidget::slotGSTaskCodeComboChanged);

    // 系统工作方式改变时,是否显示扩频和数传单选按钮
    connect(ui->systemWorkWay, static_cast<void (QComboBox::*)(int)>(&QComboBox::currentIndexChanged), this,
            &TaskProcessControlWidget::slotIsShowRadioBtn);

    // 快捷控制和手动控制界面切换
    connect(ui->controlTabWidget, &QTabWidget::currentChanged, this, &TaskProcessControlWidget::slotContrlTabChanged);

    // 资源释放
    connect(ui->resourceReleaseBtn, &QPushButton::clicked, this, &TaskProcessControlWidget::slotResourceReleaseBtnClick);
    // 下发参数宏
    connect(ui->setParamMacroBtn, &QPushButton::clicked, this, &TaskProcessControlWidget::slotSetParamMacroBtnClick);
    // 链路配置
    connect(ui->linkSetBtn, &QPushButton::clicked, this, &TaskProcessControlWidget::slotLinkSetBtnClick);
    // 一键校零
    connect(ui->oneKeyXLBtn, &QPushButton::clicked, this, &TaskProcessControlWidget::slotOneKeyXLBtnClick);

    // 根据任务代号添加对应的点频
    changedPointFreq(ui->ckTaskCodeCombo1, ui->ckPointFreqCombo1);
    changedPointFreq(ui->ckTaskCodeCombo2, ui->ckPointFreqCombo2);
    changedPointFreq(ui->ckTaskCodeCombo3, ui->ckPointFreqCombo3);
    changedPointFreq(ui->ckTaskCodeCombo4, ui->ckPointFreqCombo4);

    changedPointFreq(ui->ckTaskCodeCombo1_2, ui->ckPointFreqCombo1_2);
    changedPointFreq(ui->ckTaskCodeCombo2_2, ui->ckPointFreqCombo2_2);
    changedPointFreq(ui->ckTaskCodeCombo3_2, ui->ckPointFreqCombo3_2);
    changedPointFreq(ui->ckTaskCodeCombo4_2, ui->ckPointFreqCombo4_2);

    changedPointFreq(ui->scTaskCodeCombo1, ui->scPointFreqCombo1);
    changedPointFreq(ui->scTaskCodeCombo2, ui->scPointFreqCombo2);

    changedPointFreq(ui->sdTaskCodeCombo1, ui->sdPointFreqCombo1);
    changedPointFreq(ui->sdTaskCodeCombo2, ui->sdPointFreqCombo2);
    changedPointFreq(ui->sdTaskCodeCombo3, ui->sdPointFreqCombo3);
    changedPointFreq(ui->sdTaskCodeCombo4, ui->sdPointFreqCombo4);

    connect(m_systemCaptureProcessControl, &SystemCaptureProcessControl::signalsCmdDeviceJson, this, &TaskProcessControlWidget::signalsCmdDeviceJson);
    connect(m_systemCaptureProcessControl, &SystemCaptureProcessControl::signalsUnitDeviceJson, this,
            &TaskProcessControlWidget::signalsUnitDeviceJson);
}

void TaskProcessControlWidget::hpTableReare()
{
    ui->hpTabWidget->clear();
    m_sHP->setVisible(false);
    m_kaCKHP->setVisible(false);
    m_kaSCHP->setVisible(false);

    auto curCKMode = ui->ckWorkModeCombo->currentData().toUInt();
    auto curSCMode = ui->scWorkModeCombo->currentData().toUInt();
    switch (curCKMode)
    {
    case STTC: /* STTC */
    case Skuo2:
    case SYTHSMJ:
    case SYTHWX:
    case SYTHGML:
    case SYTHSMJK2GZB:
    case SYTHSMJK2BGZB:
    case SYTHWXSK2:
    case SYTHGMLSK2:
    case SKT:
    {
        ui->hpTabWidget->addTab(m_sHP, "S功放");
        break;
    }
    case KaKuo2: /* KaK2 */
    {
        ui->hpTabWidget->addTab(m_kaCKHP, "Ka测控功放");
        break;
    }
    }

    switch (curSCMode)
    {
    case XDS:  /* X低速数传 */
    case KaGS: /* Ka高速数传 */
    {
        break;
    }
    case KaDS: /* Ka低速数传 */
    {
        ui->hpTabWidget->addTab(m_kaSCHP, "Ka数传功放");
        break;
    }
    }
}

void TaskProcessControlWidget::hpTableReareManual()
{
    ui->hpTabWidget->clear();
    m_sHP->setVisible(false);
    m_kaCKHP->setVisible(false);
    m_kaSCHP->setVisible(false);

    auto curMode = ui->sdWorkModeCombo->currentData().toUInt();
    switch (curMode)
    {
    case STTC: /* STTC */
    case Skuo2:
    case SYTHSMJ:
    case SYTHWX:
    case SYTHGML:
    case SYTHSMJK2GZB:
    case SYTHSMJK2BGZB:
    case SYTHWXSK2:
    case SYTHGMLSK2:
    case SKT:
    {
        ui->hpTabWidget->addTab(m_sHP, "S功放");
        break;
    }
    case KaKuo2: /* KaK2 */
    {
        ui->hpTabWidget->addTab(m_kaCKHP, "Ka测控功放");
        break;
    }
    case XDS:  /* X低速数传 */
    case KaGS: /* Ka高速数传 */
    {
        break;
    }
    case KaDS: /* Ka低速数传 */
    {
        ui->hpTabWidget->addTab(m_kaSCHP, "Ka数传功放");
        break;
    }
    default: break;
    }
}

void TaskProcessControlWidget::manualFunction(ManualType type)
{
    ManualMessage manualMsg;
    manualMsg.manualType = ManualType(type);
    manualMsg.linkMasterSlave = (MasterSlave)mMasterSlaveLinkBtnGroup.checkedId();  // 使用主用链路还是备用链路

    int index = ui->controlTabWidget->currentIndex();
    if (index == 0)  // 快捷控制界面
    {
        /* 测控第一个Tabl */
        // 先判断测控是否可用
        auto currentCKMode = ui->ckWorkModeCombo->currentData().toUInt();
        if (currentCKMode != NotDefine)
        {
            LinkLine linkLine;
            linkLine.workMode = (SystemWorkMode)ui->ckWorkModeCombo->currentData().toUInt();  // 工作模式
            linkLine.masterTargetNo = mCkTargetNoBtnGroup.checkedId();                        // 主跟目标号
            linkLine.linkType = (LinkType)ui->systemWorkWay->currentData().toInt();           // 链路类型

            // TODO add by wjy,主要用于判断校零使用一体化还是扩频
            if (linkLine.workMode == SystemWorkMode::SYTHSMJK2GZB || linkLine.workMode == SystemWorkMode::SYTHSMJK2BGZB ||
                linkLine.workMode == SystemWorkMode::SYTHWXSK2 || linkLine.workMode == SystemWorkMode::SYTHGMLSK2)
            {
                if (linkLine.masterTargetNo == 1)
                {
                    linkLine.masterLink = MasterType::YTH_DT;
                }
                else if (linkLine.masterTargetNo == 2)
                {
                    linkLine.masterLink = MasterType::YTH_KP;
                }
            }

            // 一体化+XXX 模式，固定第一个目标为一体化，第二个目标为扩频
            if (SystemWorkModeHelper::isMixWorkMode(linkLine.workMode))
            {
                if (ui->ckTaskCodeCombo1->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.targetNo = 1;
                    targetInfo.taskCode = ui->ckTaskCodeCombo1->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo1->currentData().toUInt();
                    targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                    linkLine.targetMap[targetInfo.targetNo] = targetInfo;
                }

                if (ui->ckTaskCodeCombo2->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.targetNo = 2;
                    targetInfo.taskCode = ui->ckTaskCodeCombo2->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo2->currentData().toUInt();
                    targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                    linkLine.targetMap[targetInfo.targetNo] = targetInfo;
                }
            }
            else
            {
                QList<TargetInfo> targetInfoList;
                if (ui->ckTaskCodeCombo1->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.taskCode = ui->ckTaskCodeCombo1->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo1->currentData().toUInt();
                    targetInfo.workMode = linkLine.workMode;

                    targetInfoList << targetInfo;
                }

                if (ui->ckTaskCodeCombo2->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.taskCode = ui->ckTaskCodeCombo2->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo2->currentData().toUInt();
                    targetInfo.workMode = linkLine.workMode;

                    targetInfoList << targetInfo;
                }

                if (ui->ckTaskCodeCombo3->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.taskCode = ui->ckTaskCodeCombo3->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo3->currentData().toUInt();
                    targetInfo.workMode = linkLine.workMode;

                    targetInfoList << targetInfo;
                }

                if (ui->ckTaskCodeCombo4->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.taskCode = ui->ckTaskCodeCombo4->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo4->currentData().toUInt();
                    targetInfo.workMode = linkLine.workMode;

                    targetInfoList << targetInfo;
                }

                // 如果扩频4目标，按照选择的几个就下给前几个目标
                for (int targetNo = 1; targetNo <= targetInfoList.size(); ++targetNo)
                {
                    auto& targetInfo = targetInfoList[targetNo - 1];
                    targetInfo.targetNo = targetNo;
                    linkLine.targetMap[targetInfo.targetNo] = targetInfo;
                }
            }

            // 主用扩频还是数传（一体化+XXX中使用）
            if (ui->kpRB->isVisible() && ui->dtRB->isVisible())
            {
                if (ui->kpRB->isChecked())
                {
                    linkLine.masterLink = MasterType::YTH_KP;
                }
                if (ui->dtRB->isChecked())
                {
                    linkLine.masterLink = MasterType::YTH_DT;
                }
            }

            manualMsg.appendLine(linkLine);
        }

        /* 测控第二个Tabl */
        // 先判断测控是否可用
        auto currentCKMode2 = ui->ckWorkModeCombo_2->currentData().toUInt();
        if (currentCKMode2 != NotDefine)
        {
            LinkLine linkLine;
            linkLine.workMode = (SystemWorkMode)ui->ckWorkModeCombo_2->currentData().toUInt();  // 工作模式
            linkLine.masterTargetNo = mCkTargetNoBtnGroup2.checkedId();                         // 主跟目标号
            linkLine.linkType = (LinkType)ui->systemWorkWay->currentData().toInt();             // 链路类型

            // TODO add by wjy,主要用于判断校零使用一体化还是扩频
            if (linkLine.workMode == SystemWorkMode::SYTHSMJK2GZB || linkLine.workMode == SystemWorkMode::SYTHSMJK2BGZB ||
                linkLine.workMode == SystemWorkMode::SYTHWXSK2 || linkLine.workMode == SystemWorkMode::SYTHGMLSK2)
            {
                if (linkLine.masterTargetNo == 1)
                {
                    linkLine.masterLink = MasterType::YTH_DT;
                }
                else if (linkLine.masterTargetNo == 2)
                {
                    linkLine.masterLink = MasterType::YTH_KP;
                }
            }

            // 一体化+XXX 模式，固定第一个目标为一体化，第二个目标为扩频
            if (SystemWorkModeHelper::isMixWorkMode(linkLine.workMode))
            {
                if (ui->ckTaskCodeCombo1_2->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.targetNo = 1;
                    targetInfo.taskCode = ui->ckTaskCodeCombo1_2->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo1_2->currentData().toUInt();
                    targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                    linkLine.targetMap[targetInfo.targetNo] = targetInfo;
                }

                if (ui->ckTaskCodeCombo2_2->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.targetNo = 2;
                    targetInfo.taskCode = ui->ckTaskCodeCombo2_2->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo2_2->currentData().toUInt();
                    targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                    linkLine.targetMap[targetInfo.targetNo] = targetInfo;
                }
            }
            else
            {
                QList<TargetInfo> targetInfoList;
                if (ui->ckTaskCodeCombo1_2->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.taskCode = ui->ckTaskCodeCombo1_2->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo1_2->currentData().toUInt();
                    targetInfo.workMode = linkLine.workMode;

                    targetInfoList << targetInfo;
                }

                if (ui->ckTaskCodeCombo2_2->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.taskCode = ui->ckTaskCodeCombo2_2->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo2_2->currentData().toUInt();
                    targetInfo.workMode = linkLine.workMode;

                    targetInfoList << targetInfo;
                }

                if (ui->ckTaskCodeCombo3_2->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.taskCode = ui->ckTaskCodeCombo3_2->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo3_2->currentData().toUInt();
                    targetInfo.workMode = linkLine.workMode;

                    targetInfoList << targetInfo;
                }

                if (ui->ckTaskCodeCombo4_2->currentText() != "无")
                {
                    TargetInfo targetInfo;
                    targetInfo.taskCode = ui->ckTaskCodeCombo4_2->currentText();
                    targetInfo.pointFreqNo = ui->ckPointFreqCombo4_2->currentData().toUInt();
                    targetInfo.workMode = linkLine.workMode;

                    targetInfoList << targetInfo;
                }

                // 如果扩频4目标，按照选择的几个就下给前几个目标
                for (int targetNo = 1; targetNo <= targetInfoList.size(); ++targetNo)
                {
                    auto& targetInfo = targetInfoList[targetNo - 1];
                    targetInfo.targetNo = targetNo;
                    linkLine.targetMap[targetInfo.targetNo] = targetInfo;
                }
            }

            // 主用扩频还是数传（一体化+XXX中使用）
            if (ui->kpRB->isVisible() && ui->dtRB->isVisible())
            {
                if (ui->kpRB->isChecked())
                {
                    linkLine.masterLink = MasterType::YTH_KP;
                }
                if (ui->dtRB->isChecked())
                {
                    linkLine.masterLink = MasterType::YTH_DT;
                }
            }

            manualMsg.appendLine(linkLine);
        }

        // 判断数传是否可用
        auto currentSCMode = ui->scWorkModeCombo->currentData().toUInt();
        if (currentSCMode != NotDefine)
        {
            LinkLine linkLine;
            linkLine.workMode = (SystemWorkMode)ui->scWorkModeCombo->currentData().toUInt();  // 工作模式
            linkLine.masterTargetNo = mSCTargetNoBtnGroup.checkedId();                        // 主跟目标号
            linkLine.linkType = (LinkType)ui->systemWorkWay->currentData().toInt();           // 链路类型

            if (ui->scTaskCodeCombo1->currentText() != "无")
            {
                TargetInfo targetInfo;
                targetInfo.targetNo = 1;
                targetInfo.taskCode = ui->scTaskCodeCombo1->currentText();
                targetInfo.pointFreqNo = ui->scPointFreqCombo1->currentData().toUInt();
                targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                linkLine.targetMap[targetInfo.targetNo] = targetInfo;
            }

            if (ui->scTaskCodeCombo2->currentText() != "无")
            {
                TargetInfo targetInfo;
                targetInfo.targetNo = 2;
                targetInfo.taskCode = ui->scTaskCodeCombo2->currentText();
                targetInfo.pointFreqNo = ui->scPointFreqCombo2->currentData().toUInt();
                targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                linkLine.targetMap[targetInfo.targetNo] = targetInfo;
            }

            manualMsg.appendLine(linkLine);
        }
    }
    else if (index == 1)  // 手动控制界面
    {
        manualMsg.isManualContrl = true;

        auto currentMode = ui->sdWorkModeCombo->currentData().toUInt();
        if (currentMode != NotDefine)
        {
            LinkLine linkLine;
            linkLine.workMode = (SystemWorkMode)ui->sdWorkModeCombo->currentData().toUInt();  // 工作模式
            linkLine.linkType = (LinkType)ui->systemWorkWay->currentData().toInt();           // 链路类型
            linkLine.masterTargetNo = mSDTargetNoBtnGroup.checkedId();                        // 主跟目标号

            // TODO add by wjy,主要用于判断校零使用一体化还是扩频
            if (linkLine.workMode == SystemWorkMode::SYTHSMJK2GZB || linkLine.workMode == SystemWorkMode::SYTHSMJK2BGZB ||
                linkLine.workMode == SystemWorkMode::SYTHWXSK2 || linkLine.workMode == SystemWorkMode::SYTHGMLSK2)
            {
                if (linkLine.masterTargetNo == 1)
                {
                    linkLine.masterLink = MasterType::YTH_DT;
                }
                else if (linkLine.masterTargetNo == 2)
                {
                    linkLine.masterLink = MasterType::YTH_KP;
                }
            }

            if (ui->sdTaskCodeCombo1->currentText() != "无")
            {
                TargetInfo targetInfo;
                targetInfo.targetNo = 1;
                targetInfo.taskCode = ui->sdTaskCodeCombo1->currentText();
                targetInfo.pointFreqNo = ui->sdPointFreqCombo1->currentData().toUInt();
                targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                linkLine.targetMap[targetInfo.targetNo] = targetInfo;
            }

            if (ui->sdTaskCodeCombo2->currentText() != "无")
            {
                TargetInfo targetInfo;
                targetInfo.targetNo = 2;
                targetInfo.taskCode = ui->sdTaskCodeCombo2->currentText();
                targetInfo.pointFreqNo = ui->sdPointFreqCombo2->currentData().toUInt();
                targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                linkLine.targetMap[targetInfo.targetNo] = targetInfo;
            }

            if (ui->sdTaskCodeCombo3->currentText() != "无")
            {
                TargetInfo targetInfo;
                targetInfo.targetNo = 3;
                targetInfo.taskCode = ui->sdTaskCodeCombo3->currentText();
                targetInfo.pointFreqNo = ui->sdPointFreqCombo3->currentData().toUInt();
                targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                linkLine.targetMap[targetInfo.targetNo] = targetInfo;
            }

            if (ui->sdTaskCodeCombo4->currentText() != "无")
            {
                TargetInfo targetInfo;
                targetInfo.targetNo = 4;
                targetInfo.taskCode = ui->sdTaskCodeCombo4->currentText();
                targetInfo.pointFreqNo = ui->sdPointFreqCombo4->currentData().toUInt();
                targetInfo.workMode = SystemWorkModeHelper::getTargetWorkMode(linkLine.workMode, targetInfo.targetNo);

                linkLine.targetMap[targetInfo.targetNo] = targetInfo;
            }

            // 主用扩频还是数传（一体化+XXX中使用）
            if (ui->kpRB->isVisible() && ui->dtRB->isVisible())
            {
                if (ui->kpRB->isChecked())
                {
                    linkLine.masterLink = MasterType::YTH_KP;
                }
                if (ui->dtRB->isChecked())
                {
                    linkLine.masterLink = MasterType::YTH_DT;
                }
            }

            // 获取手动控制界面选择的设备信息
            ConfigMacroData configMacroData;
            getConfigMacroData(configMacroData);

            if (!linkLine.targetMap.isEmpty())
            {
                // 判断选择的设备主备是不是一样的
                if (SystemWorkModeHelper::isMeasureContrlWorkMode(linkLine.workMode))
                {
                    DeviceID masterCKJDDeviceID;
                    DeviceID slaveCKJDDeviceID;
                    configMacroData.getCKJDDeviceID(linkLine.workMode, masterCKJDDeviceID, 1);
                    configMacroData.getCKJDDeviceID(linkLine.workMode, slaveCKJDDeviceID, 2);

                    if (masterCKJDDeviceID == slaveCKJDDeviceID)
                    {
                        QMessageBox::information(this, "提示", "测控基带主备不能相同", "确定");
                        return;
                    }
                }
                else if (SystemWorkModeHelper::isDsDataTransmissionWorkMode(linkLine.workMode))
                {
                    DeviceID masterDSJDDeviceID;
                    DeviceID slaveDSJDDeviceID;
                    configMacroData.getDSJDDeviceID(linkLine.workMode, masterDSJDDeviceID, 1);
                    configMacroData.getDSJDDeviceID(linkLine.workMode, slaveDSJDDeviceID, 2);

                    if (masterDSJDDeviceID == slaveDSJDDeviceID)
                    {
                        QMessageBox::information(this, "提示", "低速基带主备不能相同", "确定");
                        return;
                    }
                }
                else if (SystemWorkModeHelper::isGsDataTransmissionWorkMode(linkLine.workMode))
                {
                    auto curProject = ExtendedConfig::curProjectID();
                    if (curProject == "4424")
                    {
                        DeviceID GSJDDeviceID1;
                        DeviceID GSJDDeviceID2;
                        DeviceID GSJDDeviceID3;

                        configMacroData.getGSJDDeviceID(linkLine.workMode, GSJDDeviceID1, 1);
                        configMacroData.getGSJDDeviceID(linkLine.workMode, GSJDDeviceID2, 2);
                        configMacroData.getGSJDDeviceID(linkLine.workMode, GSJDDeviceID3, 3);

                        if (GSJDDeviceID1 == GSJDDeviceID2 || GSJDDeviceID1 == GSJDDeviceID2 || GSJDDeviceID2 == GSJDDeviceID3)
                        {
                            QMessageBox::information(this, "提示", "高速基带主备不能相同", "确定");
                            return;
                        }
                    }
                    // 4426只有两台高速基带 一主一备
                    else if (curProject == "4426")
                    {
                        DeviceID masterGSJDDeviceID;
                        DeviceID slaveGSJDDeviceID;
                        configMacroData.getGSJDDeviceID(linkLine.workMode, masterGSJDDeviceID, 1);
                        configMacroData.getGSJDDeviceID(linkLine.workMode, slaveGSJDDeviceID, 2);

                        if (masterGSJDDeviceID == slaveGSJDDeviceID)
                        {
                            QMessageBox::information(this, "提示", "高速基带主备不能相同", "确定");
                            return;
                        }
                    }
                }
            }

            manualMsg.configMacroData = configMacroData;
            manualMsg.appendLine(linkLine);
        }
    }

    QString json;
    json << manualMsg;
    qDebug().noquote() << json;

    emit signalManualFunction(json);
}

void TaskProcessControlWidget::getConfigMacroData(ConfigMacroData& configMacroData)
{
    auto currentWorkMode = (SystemWorkMode)ui->sdWorkModeCombo->currentData().toInt();
    if (currentWorkMode == NotDefine)
    {
        return;
    }

    configMacroData.configMacroID = QString("手动控制界面设备信息");
    configMacroData.configMacroName = configMacroData.configMacroID;

    auto treeWidget = qobject_cast<QTreeWidget*>(mDeviceWidgetMap.value(currentWorkMode));
    if (treeWidget == nullptr)
    {
        return;
    }

    ConfigMacroCmdList cmdList;
    for (int topLeveItemIndex = 0; topLeveItemIndex < treeWidget->topLevelItemCount(); ++topLeveItemIndex)
    {
        auto topLeveItem = treeWidget->topLevelItem(topLeveItemIndex);

        auto comboBox = qobject_cast<QComboBox*>(treeWidget->itemWidget(topLeveItem, 1));
        if (comboBox == nullptr)
        {
            continue;
        }

        auto item = comboBox->property("Item").value<Item>();

        // Item 转为 ConfigMacroCmd
        ConfigMacroCmd configMacroCmd;
        configMacroCmd.id = item.id;                     // id
        configMacroCmd.desc = item.desc;                 // 描述
        configMacroCmd.value = comboBox->currentData();  // 当前选择的值
        for (auto enumEntry : item.enums)
        {
            if (enumEntry.value == configMacroCmd.value)
            {
                configMacroCmd.deviceID = enumEntry.deviceId;  // 当前选中的设备id（测控前端、跟踪前端、下变频器）
                break;
            }
        }

        cmdList.append(configMacroCmd);
    }
    // 获取模式id
    configMacroData.configMacroCmdListMap[currentWorkMode] = cmdList;
}

void TaskProcessControlWidget::changeSystemWorkWay()
{
    auto index = ui->controlTabWidget->currentIndex();
    if (index == 0)  // 快捷控制界面
    {
        // 当前测控tab页
        int currentCKTablIndex = ui->ckTabWidget->currentIndex();
        SystemWorkMode currentMeaConMode = NotDefine;
        if (currentCKTablIndex == 0)
        {
            currentMeaConMode = (SystemWorkMode)ui->ckWorkModeCombo->currentData().toInt();
        }
        else if (currentCKTablIndex == 1)
        {
            currentMeaConMode = (SystemWorkMode)ui->ckWorkModeCombo_2->currentData().toInt();
        }

        auto currentDataTransMode = (SystemWorkMode)ui->scWorkModeCombo->currentData().toInt();

        ui->systemWorkWay->clear();

        // 只有选择了测控模式
        if ((currentMeaConMode != NotDefine) && (currentDataTransMode == NotDefine))
        {
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::RWFS), static_cast<int>(LinkType::RWFS));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::LSYDJYXBH), static_cast<int>(LinkType::LSYDJYXBH));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::PKXLBPQBH), static_cast<int>(LinkType::PKXLBPQBH));
            // ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::SPMNYWXBH), static_cast<int>(LinkType::SPMNYWXBH));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::SPMNYYXBH), static_cast<int>(LinkType::SPMNYYXBH));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::SZHBH), static_cast<int>(LinkType::SZHBH));
        }
        // 只选择了数传模式
        else if ((currentMeaConMode == NotDefine) && (currentDataTransMode != NotDefine))
        {
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::RWFS), static_cast<int>(LinkType::RWFS));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::ZPBH), static_cast<int>(LinkType::ZPBH));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::SPMNYYXBH), static_cast<int>(LinkType::SPMNYYXBH));
        }
        // 测控数传都选择
        else if ((currentMeaConMode != NotDefine) && (currentDataTransMode != NotDefine))
        {
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::RWFS), static_cast<int>(LinkType::RWFS));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::SPMNYYXBH), static_cast<int>(LinkType::SPMNYYXBH));
        }
    }
    else if (index == 1)  // 手动控制界面
    {
        auto currentMode = (SystemWorkMode)ui->sdWorkModeCombo->currentData().toInt();

        ui->systemWorkWay->clear();

        // 选择的是测控模式
        if (SystemWorkModeHelper::isMeasureContrlWorkMode(currentMode))
        {
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::RWFS), static_cast<int>(LinkType::RWFS));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::LSYDJYXBH), static_cast<int>(LinkType::LSYDJYXBH));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::PKXLBPQBH), static_cast<int>(LinkType::PKXLBPQBH));
            // ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::SPMNYWXBH),static_cast<int>( LinkType::SPMNYWXBH));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::SPMNYYXBH), static_cast<int>(LinkType::SPMNYYXBH));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::SZHBH), static_cast<int>(LinkType::SZHBH));
        }
        // 选择的是数传模式
        else if (SystemWorkModeHelper::isDataTransmissionWorkMode(currentMode))
        {
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::RWFS), static_cast<int>(LinkType::RWFS));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::ZPBH), static_cast<int>(LinkType::ZPBH));
            ui->systemWorkWay->addItem(PlanRunHelper::getLinkTypeDesc(LinkType::SPMNYYXBH), static_cast<int>(LinkType::SPMNYYXBH));
        }
    }
}

void TaskProcessControlWidget::changeTarget(SystemWorkMode workMode)
{
    if (workMode == NotDefine)
    {
        return;
    }

    auto index = ui->controlTabWidget->currentIndex();
    if (index == 0)  // 快捷控制界面
    {
        // 默认主跟目标第一个
        ui->ckTargetRadioBtn1->setChecked(true);

        // 对于单体制，只能选择第一行，一体化+XXX的可以选择两行，扩频的可以选择4行
        switch (workMode)
        {
        case STTC: m_systemCaptureProcessControl->setEnabled(true);  // S标准TTC
        case SYTHSMJ:                                                // 一体化上面级
        case SYTHWX:                                                 // 一体化卫星
        case SYTHGML:                                                // 一体化高码率
        case SKT:                                                    // 扩跳
        {
            ui->ckTargetRadioBtn1->setEnabled(true);
            ui->ckTaskCodeCombo1->setEnabled(true);
            ui->ckPointFreqCombo1->setEnabled(true);

            ui->ckTargetRadioBtn2->setEnabled(false);
            ui->ckTaskCodeCombo2->setEnabled(false);
            ui->ckPointFreqCombo2->setEnabled(false);

            ui->ckTargetRadioBtn3->setEnabled(false);
            ui->ckTaskCodeCombo3->setEnabled(false);
            ui->ckPointFreqCombo3->setEnabled(false);

            ui->ckTargetRadioBtn4->setEnabled(false);
            ui->ckTaskCodeCombo4->setEnabled(false);
            ui->ckPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto taskCode : mWorkModeTaskcodeMap[workMode])
            {
                ui->ckTaskCodeCombo1->addItem(taskCode, workMode);
            }
        }
        break;
        case Skuo2:   // S扩二
        case KaKuo2:  // Ka扩二
        {
            ui->ckTargetRadioBtn1->setEnabled(true);
            ui->ckTaskCodeCombo1->setEnabled(true);
            ui->ckPointFreqCombo1->setEnabled(true);

            ui->ckTargetRadioBtn2->setEnabled(true);
            ui->ckTaskCodeCombo2->setEnabled(true);
            ui->ckPointFreqCombo2->setEnabled(true);

            ui->ckTargetRadioBtn3->setEnabled(true);
            ui->ckTaskCodeCombo3->setEnabled(true);
            ui->ckPointFreqCombo3->setEnabled(true);

            ui->ckTargetRadioBtn4->setEnabled(true);
            ui->ckTaskCodeCombo4->setEnabled(true);
            ui->ckPointFreqCombo4->setEnabled(true);

            // 添加任务代号
            for (auto taskCode : mWorkModeTaskcodeMap[workMode])
            {
                ui->ckTaskCodeCombo1->addItem(taskCode, workMode);
                ui->ckTaskCodeCombo2->addItem(taskCode, workMode);
                ui->ckTaskCodeCombo3->addItem(taskCode, workMode);
                ui->ckTaskCodeCombo4->addItem(taskCode, workMode);
            }
        }
        break;
        case SYTHSMJK2GZB:  // 一体化上面级+扩二共载波
        {
            ui->ckTargetRadioBtn1->setEnabled(true);
            ui->ckTaskCodeCombo1->setEnabled(true);
            ui->ckPointFreqCombo1->setEnabled(true);

            ui->ckTargetRadioBtn2->setEnabled(true);
            ui->ckTaskCodeCombo2->setEnabled(true);
            ui->ckPointFreqCombo2->setEnabled(true);

            ui->ckTargetRadioBtn3->setEnabled(false);
            ui->ckTaskCodeCombo3->setEnabled(false);
            ui->ckPointFreqCombo3->setEnabled(false);

            ui->ckTargetRadioBtn4->setEnabled(false);
            ui->ckTaskCodeCombo4->setEnabled(false);
            ui->ckPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto tempWorkMode : mWorkModeTaskcodeMap.keys())
            {
                const auto& taskCodeList = mWorkModeTaskcodeMap.value(tempWorkMode);
                if (tempWorkMode == SYTHSMJ)  // 第一个目标为一体化上面级
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->ckTaskCodeCombo1->addItem(taskCode, tempWorkMode);
                    }
                }
                else if (tempWorkMode == Skuo2)  // 第二个目标为扩频
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->ckTaskCodeCombo2->addItem(taskCode, tempWorkMode);
                    }
                }
            }
        }
        break;
        case SYTHSMJK2BGZB:  // 一体化上面级+扩二不共载波
        {
            ui->ckTargetRadioBtn1->setEnabled(true);
            ui->ckTaskCodeCombo1->setEnabled(true);
            ui->ckPointFreqCombo1->setEnabled(true);

            ui->ckTargetRadioBtn2->setEnabled(true);
            ui->ckTaskCodeCombo2->setEnabled(true);
            ui->ckPointFreqCombo2->setEnabled(true);

            ui->ckTargetRadioBtn3->setEnabled(false);
            ui->ckTaskCodeCombo3->setEnabled(false);
            ui->ckPointFreqCombo3->setEnabled(false);

            ui->ckTargetRadioBtn4->setEnabled(false);
            ui->ckTaskCodeCombo4->setEnabled(false);
            ui->ckPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto tempWorkMode : mWorkModeTaskcodeMap.keys())
            {
                const auto& taskCodeList = mWorkModeTaskcodeMap.value(tempWorkMode);
                if (tempWorkMode == SYTHSMJ)  // 第一个目标为一体化上面级
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->ckTaskCodeCombo1->addItem(taskCode, tempWorkMode);
                    }
                }
                else if (tempWorkMode == Skuo2)  // 第二个目标为扩频
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->ckTaskCodeCombo2->addItem(taskCode, tempWorkMode);
                    }
                }
            }
        }
        break;
        case SYTHWXSK2:  // 一体化卫星+扩二
        {
            ui->ckTargetRadioBtn1->setEnabled(true);
            ui->ckTaskCodeCombo1->setEnabled(true);
            ui->ckPointFreqCombo1->setEnabled(true);

            ui->ckTargetRadioBtn2->setEnabled(true);
            ui->ckTaskCodeCombo2->setEnabled(true);
            ui->ckPointFreqCombo2->setEnabled(true);

            ui->ckTargetRadioBtn3->setEnabled(false);
            ui->ckTaskCodeCombo3->setEnabled(false);
            ui->ckPointFreqCombo3->setEnabled(false);

            ui->ckTargetRadioBtn4->setEnabled(false);
            ui->ckTaskCodeCombo4->setEnabled(false);
            ui->ckPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto tempWorkMode : mWorkModeTaskcodeMap.keys())
            {
                const auto& taskCodeList = mWorkModeTaskcodeMap.value(tempWorkMode);
                if (tempWorkMode == SYTHWX)  // 第一个目标为一体化卫星
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->ckTaskCodeCombo1->addItem(taskCode, tempWorkMode);
                    }
                }
                else if (tempWorkMode == Skuo2)  // 第二个目标为扩频
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->ckTaskCodeCombo2->addItem(taskCode, tempWorkMode);
                    }
                }
            }
        }
        break;
        case SYTHGMLSK2:  // 一体化高码率+扩二
        {
            ui->ckTargetRadioBtn1->setEnabled(true);
            ui->ckTaskCodeCombo1->setEnabled(true);
            ui->ckPointFreqCombo1->setEnabled(true);

            ui->ckTargetRadioBtn2->setEnabled(true);
            ui->ckTaskCodeCombo2->setEnabled(true);
            ui->ckPointFreqCombo2->setEnabled(true);

            ui->ckTargetRadioBtn3->setEnabled(false);
            ui->ckTaskCodeCombo3->setEnabled(false);
            ui->ckPointFreqCombo3->setEnabled(false);

            ui->ckTargetRadioBtn4->setEnabled(false);
            ui->ckTaskCodeCombo4->setEnabled(false);
            ui->ckPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto tempWorkMode : mWorkModeTaskcodeMap.keys())
            {
                const auto& taskCodeList = mWorkModeTaskcodeMap.value(tempWorkMode);
                if (tempWorkMode == SYTHGML)  // 第一个目标为一体化高码率
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->ckTaskCodeCombo1->addItem(taskCode, tempWorkMode);
                    }
                }
                else if (tempWorkMode == Skuo2)  // 第二个目标为扩频
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->ckTaskCodeCombo2->addItem(taskCode, tempWorkMode);
                    }
                }
            }
        }
        break;
        case KaGS:  // Ka高速
        case XGS:   // X高速
        {
            for (auto taskCode : mWorkModeTaskcodeMap[workMode])
            {
                ui->scTaskCodeCombo1->addItem(taskCode, workMode);
                ui->scTaskCodeCombo2->addItem(taskCode, workMode);
            }
        }
        break;
        case KaDS:  // Ka低速
        case XDS:   // X低速
        {
            for (auto taskCode : mWorkModeTaskcodeMap[workMode])
            {
                ui->scTaskCodeCombo1->addItem(taskCode, workMode);
                ui->scTaskCodeCombo2->addItem(taskCode, workMode);
            }
        }
        break;
        }
    }
    else if (index == 1)  // 手动控制界面
    {
        // 默认主跟目标第一个
        ui->sdTargetRadioBtn1->setChecked(true);

        // 对于单体制，只能选择第一行，一体化+XXX的可以选择两行，扩频的可以选择4行
        switch (workMode)
        {
        case STTC: m_systemCaptureProcessControl->setEnabled(true);  // S标准TTC
        case SYTHSMJ:                                                // 一体化上面级
        case SYTHWX:                                                 // 一体化卫星
        case SYTHGML:                                                // 一体化高码率
        case SKT:                                                    // 扩跳
        {
            ui->sdTargetRadioBtn1->setEnabled(true);
            ui->sdTaskCodeCombo1->setEnabled(true);
            ui->sdPointFreqCombo1->setEnabled(true);

            ui->sdTargetRadioBtn2->setEnabled(false);
            ui->sdTaskCodeCombo2->setEnabled(false);
            ui->sdPointFreqCombo2->setEnabled(false);

            ui->sdTargetRadioBtn3->setEnabled(false);
            ui->sdTaskCodeCombo3->setEnabled(false);
            ui->sdPointFreqCombo3->setEnabled(false);

            ui->sdTargetRadioBtn4->setEnabled(false);
            ui->sdTaskCodeCombo4->setEnabled(false);
            ui->sdPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto taskCode : mWorkModeTaskcodeMap[workMode])
            {
                ui->sdTaskCodeCombo1->addItem(taskCode, workMode);
            }
        }
        break;
        case Skuo2:   // S扩二
        case KaKuo2:  // Ka扩二
        {
            ui->sdTargetRadioBtn1->setEnabled(true);
            ui->sdTaskCodeCombo1->setEnabled(true);
            ui->sdPointFreqCombo1->setEnabled(true);

            ui->sdTargetRadioBtn2->setEnabled(true);
            ui->sdTaskCodeCombo2->setEnabled(true);
            ui->sdPointFreqCombo2->setEnabled(true);

            ui->sdTargetRadioBtn3->setEnabled(true);
            ui->sdTaskCodeCombo3->setEnabled(true);
            ui->sdPointFreqCombo3->setEnabled(true);

            ui->sdTargetRadioBtn4->setEnabled(true);
            ui->sdTaskCodeCombo4->setEnabled(true);
            ui->sdPointFreqCombo4->setEnabled(true);

            // 添加任务代号
            for (auto taskCode : mWorkModeTaskcodeMap[workMode])
            {
                ui->sdTaskCodeCombo1->addItem(taskCode, workMode);
                ui->sdTaskCodeCombo2->addItem(taskCode, workMode);
                ui->sdTaskCodeCombo3->addItem(taskCode, workMode);
                ui->sdTaskCodeCombo4->addItem(taskCode, workMode);
            }
        }
        break;
        case SYTHSMJK2GZB:  // 一体化上面级+扩二共载波
        {
            ui->sdTargetRadioBtn1->setEnabled(true);
            ui->sdTaskCodeCombo1->setEnabled(true);
            ui->sdPointFreqCombo1->setEnabled(true);

            ui->sdTargetRadioBtn2->setEnabled(true);
            ui->sdTaskCodeCombo2->setEnabled(true);
            ui->sdPointFreqCombo2->setEnabled(true);

            ui->sdTargetRadioBtn3->setEnabled(false);
            ui->sdTaskCodeCombo3->setEnabled(false);
            ui->sdPointFreqCombo3->setEnabled(false);

            ui->sdTargetRadioBtn4->setEnabled(false);
            ui->sdTaskCodeCombo4->setEnabled(false);
            ui->sdPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto tempWorkMode : mWorkModeTaskcodeMap.keys())
            {
                const auto& taskCodeList = mWorkModeTaskcodeMap.value(tempWorkMode);
                if (tempWorkMode == SYTHSMJ)  // 第一个目标为一体化上面级
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->sdTaskCodeCombo1->addItem(taskCode, tempWorkMode);
                    }
                }
                else if (tempWorkMode == Skuo2)  // 第二个目标为扩频
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->sdTaskCodeCombo2->addItem(taskCode, tempWorkMode);
                    }
                }
            }
        }
        break;
        case SYTHSMJK2BGZB:  // 一体化上面级+扩二不共载波
        {
            ui->sdTargetRadioBtn1->setEnabled(true);
            ui->sdTaskCodeCombo1->setEnabled(true);
            ui->sdPointFreqCombo1->setEnabled(true);

            ui->sdTargetRadioBtn2->setEnabled(true);
            ui->sdTaskCodeCombo2->setEnabled(true);
            ui->sdPointFreqCombo2->setEnabled(true);

            ui->sdTargetRadioBtn3->setEnabled(false);
            ui->sdTaskCodeCombo3->setEnabled(false);
            ui->sdPointFreqCombo3->setEnabled(false);

            ui->sdTargetRadioBtn4->setEnabled(false);
            ui->sdTaskCodeCombo4->setEnabled(false);
            ui->sdPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto tempWorkMode : mWorkModeTaskcodeMap.keys())
            {
                const auto& taskCodeList = mWorkModeTaskcodeMap.value(tempWorkMode);
                if (tempWorkMode == SYTHSMJ)  // 第一个目标为一体化上面级
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->sdTaskCodeCombo1->addItem(taskCode, tempWorkMode);
                    }
                }
                else if (tempWorkMode == Skuo2)  // 第二个目标为扩频
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->sdTaskCodeCombo2->addItem(taskCode, tempWorkMode);
                    }
                }
            }
        }
        break;
        case SYTHWXSK2:  // 一体化卫星+扩二
        {
            ui->sdTargetRadioBtn1->setEnabled(true);
            ui->sdTaskCodeCombo1->setEnabled(true);
            ui->sdPointFreqCombo1->setEnabled(true);

            ui->sdTargetRadioBtn2->setEnabled(true);
            ui->sdTaskCodeCombo2->setEnabled(true);
            ui->sdPointFreqCombo2->setEnabled(true);

            ui->sdTargetRadioBtn3->setEnabled(false);
            ui->sdTaskCodeCombo3->setEnabled(false);
            ui->sdPointFreqCombo3->setEnabled(false);

            ui->sdTargetRadioBtn4->setEnabled(false);
            ui->sdTaskCodeCombo4->setEnabled(false);
            ui->sdPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto tempWorkMode : mWorkModeTaskcodeMap.keys())
            {
                const auto& taskCodeList = mWorkModeTaskcodeMap.value(tempWorkMode);
                if (tempWorkMode == SYTHWX)  // 第一个目标为一体化卫星
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->sdTaskCodeCombo1->addItem(taskCode, tempWorkMode);
                    }
                }
                else if (tempWorkMode == Skuo2)  // 第二个目标为扩频
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->sdTaskCodeCombo2->addItem(taskCode, tempWorkMode);
                    }
                }
            }
        }
        break;
        case SYTHGMLSK2:  // 一体化高码率+扩二
        {
            ui->sdTargetRadioBtn1->setEnabled(true);
            ui->sdTaskCodeCombo1->setEnabled(true);
            ui->sdPointFreqCombo1->setEnabled(true);

            ui->sdTargetRadioBtn2->setEnabled(true);
            ui->sdTaskCodeCombo2->setEnabled(true);
            ui->sdPointFreqCombo2->setEnabled(true);

            ui->sdTargetRadioBtn3->setEnabled(false);
            ui->sdTaskCodeCombo3->setEnabled(false);
            ui->sdPointFreqCombo3->setEnabled(false);

            ui->sdTargetRadioBtn4->setEnabled(false);
            ui->sdTaskCodeCombo4->setEnabled(false);
            ui->sdPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto tempWorkMode : mWorkModeTaskcodeMap.keys())
            {
                const auto& taskCodeList = mWorkModeTaskcodeMap.value(tempWorkMode);
                if (tempWorkMode == SYTHGML)  // 第一个目标为一体化高码率
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->sdTaskCodeCombo1->addItem(taskCode, tempWorkMode);
                    }
                }
                else if (tempWorkMode == Skuo2)  // 第二个目标为扩频
                {
                    for (auto taskCode : taskCodeList)
                    {
                        ui->sdTaskCodeCombo2->addItem(taskCode, tempWorkMode);
                    }
                }
            }
        }
        break;
        case KaGS:  // Ka高速
        case XGS:   // X高速
        {
            ui->sdTargetRadioBtn1->setEnabled(true);
            ui->sdTaskCodeCombo1->setEnabled(true);
            ui->sdPointFreqCombo1->setEnabled(true);

            ui->sdTargetRadioBtn2->setEnabled(true);
            ui->sdTaskCodeCombo2->setEnabled(true);
            ui->sdPointFreqCombo2->setEnabled(true);

            ui->sdTargetRadioBtn3->setEnabled(false);
            ui->sdTaskCodeCombo3->setEnabled(false);
            ui->sdPointFreqCombo3->setEnabled(false);

            ui->sdTargetRadioBtn4->setEnabled(false);
            ui->sdTaskCodeCombo4->setEnabled(false);
            ui->sdPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto taskCode : mWorkModeTaskcodeMap[workMode])
            {
                ui->sdTaskCodeCombo1->addItem(taskCode, workMode);
                ui->sdTaskCodeCombo2->addItem(taskCode, workMode);
            }
        }
        break;
        case KaDS:  // Ka低速
        case XDS:   // X低速
        {
            ui->sdTargetRadioBtn1->setEnabled(true);
            ui->sdTaskCodeCombo1->setEnabled(true);
            ui->sdPointFreqCombo1->setEnabled(true);

            ui->sdTargetRadioBtn2->setEnabled(true);
            ui->sdTaskCodeCombo2->setEnabled(true);
            ui->sdPointFreqCombo2->setEnabled(true);

            ui->sdTargetRadioBtn3->setEnabled(false);
            ui->sdTaskCodeCombo3->setEnabled(false);
            ui->sdPointFreqCombo3->setEnabled(false);

            ui->sdTargetRadioBtn4->setEnabled(false);
            ui->sdTaskCodeCombo4->setEnabled(false);
            ui->sdPointFreqCombo4->setEnabled(false);

            // 添加任务代号
            for (auto taskCode : mWorkModeTaskcodeMap[workMode])
            {
                ui->sdTaskCodeCombo1->addItem(taskCode, workMode);
                ui->sdTaskCodeCombo2->addItem(taskCode, workMode);
            }
        }
        break;
        }
    }
}

void TaskProcessControlWidget::changeTarget2(SystemWorkMode workMode)
{
    // 默认主跟目标第一个
    ui->ckTargetRadioBtn1_2->setChecked(true);

    // 对于单体制，只能选择第一行，一体化+XXX的可以选择两行，扩频的可以选择4行
    switch (workMode)
    {
    case STTC: m_systemCaptureProcessControl->setEnabled(true);  // S标准TTC
    case SKT:                                                    // 扩跳
    {
        ui->ckTargetRadioBtn1_2->setEnabled(true);
        ui->ckTaskCodeCombo1_2->setEnabled(true);
        ui->ckPointFreqCombo1_2->setEnabled(true);

        ui->ckTargetRadioBtn2_2->setEnabled(false);
        ui->ckTaskCodeCombo2_2->setEnabled(false);
        ui->ckPointFreqCombo2_2->setEnabled(false);

        ui->ckTargetRadioBtn3_2->setEnabled(false);
        ui->ckTaskCodeCombo3_2->setEnabled(false);
        ui->ckPointFreqCombo3_2->setEnabled(false);

        ui->ckTargetRadioBtn4_2->setEnabled(false);
        ui->ckTaskCodeCombo4_2->setEnabled(false);
        ui->ckPointFreqCombo4_2->setEnabled(false);

        // 添加任务代号
        for (auto taskCode : mWorkModeTaskcodeMap[workMode])
        {
            ui->ckTaskCodeCombo1_2->addItem(taskCode, workMode);
        }
    }
    break;
    case Skuo2:   // S扩二
    case KaKuo2:  // Ka扩二
    {
        ui->ckTargetRadioBtn1_2->setEnabled(true);
        ui->ckTaskCodeCombo1_2->setEnabled(true);
        ui->ckPointFreqCombo1_2->setEnabled(true);

        ui->ckTargetRadioBtn2_2->setEnabled(true);
        ui->ckTaskCodeCombo2_2->setEnabled(true);
        ui->ckPointFreqCombo2_2->setEnabled(true);

        ui->ckTargetRadioBtn3_2->setEnabled(true);
        ui->ckTaskCodeCombo3_2->setEnabled(true);
        ui->ckPointFreqCombo3_2->setEnabled(true);

        ui->ckTargetRadioBtn4_2->setEnabled(true);
        ui->ckTaskCodeCombo4_2->setEnabled(true);
        ui->ckPointFreqCombo4_2->setEnabled(true);

        // 添加任务代号
        for (auto taskCode : mWorkModeTaskcodeMap[workMode])
        {
            ui->ckTaskCodeCombo1_2->addItem(taskCode, workMode);
            ui->ckTaskCodeCombo2_2->addItem(taskCode, workMode);
            ui->ckTaskCodeCombo3_2->addItem(taskCode, workMode);
            ui->ckTaskCodeCombo4_2->addItem(taskCode, workMode);
        }
    }
    break;
    }
}

void TaskProcessControlWidget::changedPointFreq(QComboBox* taskCodeCombo, QComboBox* pointFreqCombo)
{
    connect(taskCodeCombo, &QComboBox::currentTextChanged, [=]() {
        pointFreqCombo->clear();

        auto tempTaskCode = taskCodeCombo->currentText();
        auto targetWorkMode = (SystemWorkMode)taskCodeCombo->currentData().toInt();  // 获取目标的工作模式
        for (auto i = 1; i <= mTaskCodeWorkModeDpMap[tempTaskCode][targetWorkMode]; ++i)
        {
            pointFreqCombo->addItem(QString("点频%1").arg(i), i);
        }
    });
}

bool TaskProcessControlWidget::checkMistake()
{
    int index = ui->controlTabWidget->currentIndex();
    if (index == 0)  // 快捷控制界面
    {
        auto ckWorkMode = (SystemWorkMode)ui->ckWorkModeCombo->currentData().toInt();
        auto ckWorkMode2 = (SystemWorkMode)ui->ckWorkModeCombo_2->currentData().toInt();
        auto scWorkMode = (SystemWorkMode)ui->scWorkModeCombo->currentData().toInt();
        if (ckWorkMode == NotDefine && ckWorkMode2 == NotDefine && scWorkMode == NotDefine)
        {
            QMessageBox::information(this, "提示", "请至少选择一个工作模式", "确定");
            return false;
        }

        if (ckWorkMode != NotDefine)
        {
            for (auto comboBox : m_ckCombox)
            {
                if (comboBox->currentText() != QString("无"))
                {
                    break;
                }
            }
        }

        if (ui->ckWorkModeCombo->currentText() != QString("无") && ui->scWorkModeCombo->currentText() == QString("无"))
        {
            auto ckCombox = m_ckCombox[mCkTargetNoBtnGroup.checkedId()];
            if (ckCombox && ckCombox->currentText() == QString("无"))
            {
                QMessageBox::information(this, "提示", "请选择任务代号", "确定");
                return false;
            }
        }
        else if (ui->ckWorkModeCombo->currentText() == QString("无") && ui->scWorkModeCombo->currentText() != QString("无"))
        {
            auto scCombox = m_scCombox[mSCTargetNoBtnGroup.checkedId()];
            if (scCombox && scCombox->currentText() == QString("无"))
            {
                QMessageBox::information(this, "提示", "请选择任务代号", "确定");
                return false;
            }
        }
        else if (ui->ckWorkModeCombo->currentText() != QString("无") && ui->scWorkModeCombo->currentText() != QString("无"))
        {
            auto ckCombox = m_ckCombox[mCkTargetNoBtnGroup.checkedId()];
            auto scCombox = m_scCombox[mSCTargetNoBtnGroup.checkedId()];
            if (ckCombox == nullptr || scCombox == nullptr)
            {
                return false;
            }
            if (ckCombox->currentText() == QString("无") && scCombox->currentText() == QString("无"))
            {
                QMessageBox::information(this, "提示", "请选择任务代号", "确定");
                return false;
            }
        }
        else
        {
            return true;
        }
    }
    else  //手动控制界面
    {
        if (ui->sdWorkModeCombo->currentText() == QString("无"))
        {
            QMessageBox::information(this, "提示", "请至少选择一个工作模式", "确定");
            return false;
        }

        if (ui->sdWorkModeCombo->currentText() != QString("无"))
        {
            auto sdCombox = m_sdCombox[mSDTargetNoBtnGroup.checkedId()];
            if (sdCombox && sdCombox->currentText() == QString("无"))
            {
                QMessageBox::information(this, "提示", "请选择任务代号", "确定");
                return false;
            }
        }
        else
        {
            return true;
        }
    }

    return true;
}

void TaskProcessControlWidget::slotRefreshData()
{
    SatelliteManagementDataList satelliteList;
    GlobalData::getSatelliteManagementData(satelliteList);

    if (!satelliteList.size())
    {
        QMessageBox::information(this, "提示", "获取卫星数据失败", "确定");
    }

    mWorkModeTaskcodeMap.clear();
    mTaskCodeWorkModeDpMap.clear();

    for (auto item : satelliteList)
    {
        auto map = item.getworkMode();
        for (auto workModeId : map.keys())
        {
            SystemWorkMode workMode = (SystemWorkMode)workModeId;

            mWorkModeTaskcodeMap[workMode].append(map[workModeId]);
            mTaskCodeWorkModeDpMap[item.m_satelliteCode][workMode] = item.getDpNumByWorkMode(workMode);
        }
    }

    auto index = ui->controlTabWidget->currentIndex();
    if (index == 0)  // 快捷控制界面
    {
        slotCKWorkModeChanged(ui->ckWorkModeCombo->currentIndex());
        slotSCWorkModeChanged(ui->scWorkModeCombo->currentIndex());
    }
    else if (index == 1)  // 手动控制界面
    {
        slotWorkModeChanged(ui->sdWorkModeCombo->currentIndex());
    }
}

void TaskProcessControlWidget::slotCKWorkModeChanged(int)
{
    hpTableReare();

    // tab1界面工作模式更改时，手动控制界面的工作模式同步更改
    auto currentText = ui->ckWorkModeCombo->currentText();
    ui->sdWorkModeCombo->setCurrentText(currentText);

    auto workMode = (SystemWorkMode)ui->ckWorkModeCombo->currentData().toInt();
    ui->stackedWidget->setCurrentIndex(1);
    m_systemCaptureProcessControl->setShowWidget(workMode);

    // 第一个测控tab页
    ui->ckTargetRadioBtn1->setChecked(false);
    ui->ckTargetRadioBtn2->setChecked(false);
    ui->ckTargetRadioBtn3->setChecked(false);
    ui->ckTargetRadioBtn4->setChecked(false);

    ui->ckTaskCodeCombo1->clear();
    ui->ckTaskCodeCombo2->clear();
    ui->ckTaskCodeCombo3->clear();
    ui->ckTaskCodeCombo4->clear();

    ui->ckTaskCodeCombo1->addItem("无", 0);
    ui->ckTaskCodeCombo2->addItem("无", 0);
    ui->ckTaskCodeCombo3->addItem("无", 0);
    ui->ckTaskCodeCombo4->addItem("无", 0);

    ui->ckPointFreqCombo1->clear();
    ui->ckPointFreqCombo2->clear();
    ui->ckPointFreqCombo3->clear();
    ui->ckPointFreqCombo4->clear();

    // 去改变系统工作方式
    changeSystemWorkWay();
    // 根据当前测控选择的工作模式去改变可使用的目标
    changeTarget(workMode);
}

void TaskProcessControlWidget::slotCKWorkModeChanged2(int)
{
    hpTableReare();

    auto workMode = (SystemWorkMode)ui->ckWorkModeCombo_2->currentData().toInt();
    ui->stackedWidget->setCurrentIndex(1);
    m_systemCaptureProcessControl->setShowWidget(workMode);

    ui->ckTargetRadioBtn1_2->setChecked(false);
    ui->ckTargetRadioBtn2_2->setChecked(false);
    ui->ckTargetRadioBtn3_2->setChecked(false);
    ui->ckTargetRadioBtn4_2->setChecked(false);

    ui->ckTaskCodeCombo1_2->clear();
    ui->ckTaskCodeCombo2_2->clear();
    ui->ckTaskCodeCombo3_2->clear();
    ui->ckTaskCodeCombo4_2->clear();

    ui->ckTaskCodeCombo1_2->addItem("无", 0);
    ui->ckTaskCodeCombo2_2->addItem("无", 0);
    ui->ckTaskCodeCombo3_2->addItem("无", 0);
    ui->ckTaskCodeCombo4_2->addItem("无", 0);

    ui->ckPointFreqCombo1_2->clear();
    ui->ckPointFreqCombo2_2->clear();
    ui->ckPointFreqCombo3_2->clear();
    ui->ckPointFreqCombo4_2->clear();

    // 去改变系统工作方式
    changeSystemWorkWay();
    // 根据当前测控选择的工作模式去改变可使用的目标
    changeTarget2(workMode);
}

void TaskProcessControlWidget::slotSCWorkModeChanged(int)
{
    hpTableReare();

    auto workMode = (SystemWorkMode)ui->scWorkModeCombo->currentData().toInt();

    ui->scTaskCodeCombo1->clear();
    ui->scTaskCodeCombo2->clear();

    ui->scPointFreqCombo1->clear();
    ui->scPointFreqCombo2->clear();

    ui->scTargetRadioBtn1->setChecked(false);
    ui->scTargetRadioBtn2->setChecked(false);

    ui->scTaskCodeCombo1->addItem("无", 0);
    ui->scTaskCodeCombo2->addItem("无", 0);

    // 默认主跟第一个
    ui->scTargetRadioBtn1->setChecked(true);

    // 去改变系统工作方式
    changeSystemWorkWay();
    // 根据当前数传选择的工作模式去改变可使用的目标
    changeTarget(workMode);
}

void TaskProcessControlWidget::slotIsShowRadioBtn()
{
    auto systemWorkWay = (LinkType)ui->systemWorkWay->currentData().toUInt();  // 系统工作方式
    auto workMode = NotDefine;
    int index = ui->controlTabWidget->currentIndex();
    if (index == 0)
    {
        workMode = (SystemWorkMode)ui->ckWorkModeCombo->currentData().toUInt();
    }
    else if (index == 1)
    {
        workMode = (SystemWorkMode)ui->sdWorkModeCombo->currentData().toInt();
    }

    // 不是测控模式直接返回
    if (!SystemWorkModeHelper::isMeasureContrlWorkMode(workMode))
    {
        return;
    }

    auto curProject = ExtendedConfig::curProjectID();
    if (curProject == "4424")
    {
        if ((systemWorkWay == LinkType::SZHBH || systemWorkWay == LinkType::PKXLBPQBH || systemWorkWay == LinkType::SPMNYYXBH) &&
            (workMode == SYTHSMJK2GZB || workMode == SYTHSMJK2BGZB || workMode == SYTHWXSK2 || workMode == SYTHGMLSK2 || workMode == SKT))
        {
            ui->kpRB->setVisible(true);
            ui->dtRB->setVisible(true);
        }
        else
        {
            ui->kpRB->setVisible(false);
            ui->dtRB->setVisible(false);
        }
    }
    else if (curProject == "4426")
    {
        ui->kpRB->setVisible(false);
        ui->dtRB->setVisible(false);
    }
}

void TaskProcessControlWidget::slotWorkModeChanged(int index)
{
    hpTableReareManual();

    auto workMode = (SystemWorkMode)ui->sdWorkModeCombo->currentData().toInt();
    ui->stackedWidget->setCurrentIndex(1);
    m_systemCaptureProcessControl->setShowWidget(workMode);

    auto widget = mDeviceWidgetMap[workMode];
    if (widget != nullptr)
    {
        ui->deviceStackedWidget->setCurrentWidget(widget);
    }

    ui->sdTargetRadioBtn1->setChecked(false);
    ui->sdTargetRadioBtn2->setChecked(false);
    ui->sdTargetRadioBtn3->setChecked(false);
    ui->sdTargetRadioBtn4->setChecked(false);

    ui->sdTaskCodeCombo1->clear();
    ui->sdTaskCodeCombo2->clear();
    ui->sdTaskCodeCombo3->clear();
    ui->sdTaskCodeCombo4->clear();

    ui->sdTaskCodeCombo1->addItem("无", 0);
    ui->sdTaskCodeCombo2->addItem("无", 0);
    ui->sdTaskCodeCombo3->addItem("无", 0);
    ui->sdTaskCodeCombo4->addItem("无", 0);

    ui->sdPointFreqCombo1->clear();
    ui->sdPointFreqCombo2->clear();
    ui->sdPointFreqCombo3->clear();
    ui->sdPointFreqCombo4->clear();

    // 去改变系统工作方式
    changeSystemWorkWay();
    // 根据当前选择的工作模式去改变可使用的目标
    changeTarget(workMode);
}

void TaskProcessControlWidget::slotGSTaskCodeComboChanged()
{
    auto curProject = ExtendedConfig::curProjectID();
    auto currentWorkMode = (SystemWorkMode)ui->sdWorkModeCombo->currentData().toInt();
    // 当前项目是4424并且手动控制界面工作模式为数传模式
    if (curProject == "4424" && SystemWorkModeHelper::isDataTransmissionWorkMode(currentWorkMode))
    {
        auto text1 = ui->sdTaskCodeCombo1->currentText();
        auto text2 = ui->sdTaskCodeCombo2->currentText();

        int pointNum = 0;
        if (text1 != "无")
        {
            ++pointNum;
        }
        if (text2 != "无")
        {
            ++pointNum;
        }

        // 获取显示高速基带描述的 QTreeWidgetItem
        auto treeWidget = qobject_cast<QTreeWidget*>(mDeviceWidgetMap.value(currentWorkMode));
        if (treeWidget == nullptr)
        {
            return;
        }

        QList<QTreeWidgetItem*> gsjdTreeWidgetItemList;
        QList<QComboBox*> gsjdComboBoxList;
        for (int topLeveItemIndex = 0; topLeveItemIndex < treeWidget->topLevelItemCount(); ++topLeveItemIndex)
        {
            auto topLeveItem = treeWidget->topLevelItem(topLeveItemIndex);

            auto comboBox = qobject_cast<QComboBox*>(treeWidget->itemWidget(topLeveItem, 1));
            if (comboBox == nullptr)
            {
                continue;
            }

            auto item = comboBox->property("Item").value<Item>();
            // 获取高速基带描述的item
            if (item.id.contains("GSJD"))  // 配置文件中必须包含GSJD
            {
                gsjdTreeWidgetItemList << topLeveItem;
                gsjdComboBoxList << comboBox;
            }
        }

        // 4424配置宏高速模式中高数基带配置必须有3台
        if (gsjdTreeWidgetItemList.size() != 3)
        {
            return;
        }

        // 4424根据点频数进行改变id
        // 单点频情况下一主两备
        // 双点频情况下两主一备

        // 点频数只有1个
        if (pointNum == 1)
        {
            gsjdTreeWidgetItemList[0]->setText(0, "高速基带主");
            gsjdTreeWidgetItemList[1]->setText(0, "高速基带备1");
            gsjdTreeWidgetItemList[2]->setText(0, "高速基带备2");

            auto item = gsjdComboBoxList[0]->property("Item").value<Item>();
            item.id = "GSJD1";
            item.desc = "高速基带主";
            gsjdComboBoxList[0]->setProperty("Item", QVariant::fromValue<Item>(item));

            item = gsjdComboBoxList[1]->property("Item").value<Item>();
            item.id = "GSJD2";
            item.desc = "高速基带备1";
            gsjdComboBoxList[1]->setProperty("Item", QVariant::fromValue<Item>(item));

            item = gsjdComboBoxList[2]->property("Item").value<Item>();
            item.id = "GSJD3";
            item.desc = "高速基带备2";
            gsjdComboBoxList[2]->setProperty("Item", QVariant::fromValue<Item>(item));
        }
        // 点频数有2个
        else if (pointNum == 2)
        {
            gsjdTreeWidgetItemList[0]->setText(0, "高速基带主1");
            gsjdTreeWidgetItemList[1]->setText(0, "高速基带主2");
            gsjdTreeWidgetItemList[2]->setText(0, "高速基带备");

            auto item = gsjdComboBoxList[0]->property("Item").value<Item>();
            item.id = "GSJD1";
            item.desc = "高速基带主1";
            gsjdComboBoxList[0]->setProperty("Item", QVariant::fromValue<Item>(item));

            item = gsjdComboBoxList[1]->property("Item").value<Item>();
            item.id = "GSJD2";
            item.desc = "高速基带主2";
            gsjdComboBoxList[1]->setProperty("Item", QVariant::fromValue<Item>(item));

            item = gsjdComboBoxList[2]->property("Item").value<Item>();
            item.id = "GSJD3";
            item.desc = "高速基带备";
            gsjdComboBoxList[2]->setProperty("Item", QVariant::fromValue<Item>(item));
        }
    }
}

void TaskProcessControlWidget::slotContrlTabChanged(int index)
{
    // 去改变系统工作方式
    changeSystemWorkWay();
}

void TaskProcessControlWidget::slotResourceReleaseBtnClick()
{
    // 资源释放
    if (!checkMistake())  //做一些判断
    {
        return;
    }
    manualFunction(ManualType::ResourceRelease);
}

void TaskProcessControlWidget::slotSetParamMacroBtnClick()
{
    // 下发参数宏
    if (!checkMistake())  //做一些判断
    {
        return;
    }
    manualFunction(ManualType::ParamMacro);
}

void TaskProcessControlWidget::slotLinkSetBtnClick()
{
    if (0 == QMessageBox::information(this, "提示！", "是否下发链路配置", "确定", "取消"))
    {
        // 下发配置宏
        if (!checkMistake())  //做一些判断
        {
            return;
        }
        manualFunction(ManualType::ConfigMacro);
    }
}

void TaskProcessControlWidget::slotOneKeyXLBtnClick()
{
    // 一键校零
    if (!checkMistake())  //做一些判断
    {
        return;
    }
    manualFunction(ManualType::OnekeyXL);
}

void TaskProcessControlWidget::slotToACUSetProcess(int value)
{
    //    QObject* object = sender();
    //    HP* hp = dynamic_cast<HP*>(object);
    //    QByteArray data;
    //    QVariantMap params;

    //    if (m_CurProject == "4424")
    //    {
    //        switch (hp->getType())
    //        {
    //        case SCK_HP:
    //        {
    //            if (value == 1)
    //            {
    //                // A上天线B去负载，必须先把B控去负载，然后再控A上天线
    //                params.insert("SwitcherSet", 4);
    //                HPCmd::Control(0x2301, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);

    //                params.clear();
    //                params.insert("SwitcherSet", 1);
    //                HPCmd::Control(0x2301, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            }
    //            if (value == 2)
    //            {
    //                // A上天线B去负载，必须先把B控去负载，然后再控A上天线
    //                params.insert("SwitcherSet", 3);
    //                HPCmd::Control(0x2301, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);

    //                params.clear();
    //                params.insert("SwitcherSet", 2);
    //                HPCmd::Control(0x2301, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            }
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        default: break;
    //        }
    //    }

    //    if (m_CurProject == "4426")
    //    {
    //        switch (hp->getType())
    //        {
    //        case SCK_HP:
    //        {
    //            if (value == 1)
    //            {
    //                // A上天线B去负载，必须先把B控去负载，然后再控A上天线
    //                params.insert("SwitcherSet", 3);
    //                HPCmd::Control(0x2101, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);

    //                params.clear();
    //                params.insert("SwitcherSet", 1);
    //                HPCmd::Control(0x2101, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            }
    //            if (value == 2)
    //            {
    //                // A上天线B去负载，必须先把B控去负载，然后再控A上天线
    //                params.insert("SwitcherSet", 3);
    //                HPCmd::Control(0x2101, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);

    //                params.clear();
    //                params.insert("SwitcherSet", 2);
    //                HPCmd::Control(0x2101, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            }
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        case KaSCK_HP:
    //        {
    //            if (value == 1)
    //            {
    //                params.insert("RateOutput", 1);
    //                HPCmd::Control(0x2003, 0xFFFF, 0x5, params, HPCmd::ProcessControl, data);

    //                params.clear();
    //                params.insert("RateOutput", 2);
    //                HPCmd::Control(0x2004, 0xFFFF, 0x5, params, HPCmd::ProcessControl, data);
    //            }
    //            if (value == 2)
    //            {
    //                params.insert("RateOutput", 2);
    //                HPCmd::Control(0x2003, 0xFFFF, 0x5, params, HPCmd::ProcessControl, data);

    //                params.clear();
    //                params.insert("RateOutput", 1);
    //                HPCmd::Control(0x2004, 0xFFFF, 0x5, params, HPCmd::ProcessControl, data);
    //            }
    //            emit signalsCmdDeviceJson(data);
    //            break;
    //        }
    //        case KaSSC_HP:
    //        {
    //            if (value == 1)
    //            {
    //                params.insert("RateOutput", 1);
    //                HPCmd::Control(0x2005, 0xFFFF, 0x5, params, HPCmd::ProcessControl, data);

    //                params.clear();
    //                params.insert("RateOutput", 2);
    //                HPCmd::Control(0x2006, 0xFFFF, 0x5, params, HPCmd::ProcessControl, data);
    //            }
    //            if (value == 2)
    //            {
    //                params.insert("RateOutput", 2);
    //                HPCmd::Control(0x2005, 0xFFFF, 0x5, params, HPCmd::ProcessControl, data);

    //                params.clear();
    //                params.insert("RateOutput", 1);
    //                HPCmd::Control(0x2006, 0xFFFF, 0x5, params, HPCmd::ProcessControl, data);
    //            }
    //            emit signalsCmdDeviceJson(data);
    //            break;
    //        }
    //        default: break;
    //        }
    //    }
}

void TaskProcessControlWidget::slotPowerSetProcess(double value)
{
    //    QObject* object = sender();
    //    HP* hp = dynamic_cast<HP*>(object);
    //    QByteArray data;
    //    QVariantMap params;

    //    if (m_CurProject == "4424")
    //    {
    //        switch (hp->getType())
    //        {
    //        case SCK_HP:
    //        {
    //            params.insert("TransmPower", value);
    //            int currentHP = hp->getCurrentHP();
    //            int deviceId = 0x2001;
    //            if (currentHP == 1)
    //                deviceId = 0x2001;
    //            else
    //                deviceId = 0x2002;
    //            //            auto statusReportMsg = GlobalData::getExtenStatusReportData(deviceId);
    //            //            params.insert("ALControl", statusReportMsg.unitReportMsgMap[1].paramMap["ALControl"]);
    //            //            params.insert("RFOutput", statusReportMsg.unitReportMsgMap[1].paramMap["ALControl"]);
    //            HPCmd::Control(deviceId, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        default: break;
    //        }
    //    }
    //    if (m_CurProject == "4426")
    //    {
    //        switch (hp->getType())
    //        {
    //        case SCK_HP:
    //        {
    //            params.insert("TransmPower", value);
    //            int currentHP = hp->getCurrentHP();
    //            int deviceId = 0x2001;
    //            if (currentHP == 1)
    //                deviceId = 0x2001;
    //            else
    //                deviceId = 0x2002;
    //            HPCmd::Control(deviceId, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        case KaSCK_HP:
    //        {
    //            params.insert("TransmPower", value);
    //            int currentHP = hp->getCurrentHP();
    //            int deviceId = 0x2003;
    //            if (currentHP == 1)
    //                deviceId = 0x2003;
    //            else
    //                deviceId = 0x2004;
    //            HPCmd::Control(deviceId, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        case KaSSC_HP:
    //        {
    //            params.insert("TransmPower", value);
    //            int currentHP = hp->getCurrentHP();
    //            int deviceId = 0x2005;
    //            if (currentHP == 1)
    //                deviceId = 0x2005;
    //            else
    //                deviceId = 0x2006;
    //            HPCmd::Control(deviceId, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        default: break;
    //        }
    //    }
}

void TaskProcessControlWidget::slotALCSetProcess(int value)
{
    //    QObject* object = sender();
    //    HP* hp = dynamic_cast<HP*>(object);
    //    QByteArray data;
    //    QVariantMap params;

    //    if (m_CurProject == "4424")
    //    {
    //        switch (hp->getType())
    //        {
    //        default: break;
    //        }
    //    }
    //    if (m_CurProject == "4426")
    //    {
    //        switch (hp->getType())
    //        {
    //        case KaSCK_HP:
    //        {
    //            params.insert("ALControl", value);
    //            int currentHP = hp->getCurrentHP();
    //            int deviceId = 0x2003;
    //            if (currentHP == 1)
    //                deviceId = 0x2003;
    //            else
    //                deviceId = 0x2004;
    //            HPCmd::Control(deviceId, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        case KaSSC_HP:
    //        {
    //            params.insert("ALControl", value);
    //            int currentHP = hp->getCurrentHP();
    //            int deviceId = 0x2005;
    //            if (currentHP == 1)
    //                deviceId = 0x2005;
    //            else
    //                deviceId = 0x2006;
    //            HPCmd::Control(deviceId, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        default: break;
    //        }
    //    }
}

void TaskProcessControlWidget::slotOutputProcess(int value)
{
    //    QObject* object = sender();
    //    HP* hp = dynamic_cast<HP*>(object);
    //    QByteArray data;
    //    QVariantMap params;

    //    if (m_CurProject == "4426")
    //    {
    //        switch (hp->getType())
    //        {
    //        case SCK_HP:
    //        {
    //            params.insert("ElectricControlor", value);
    //            int currentHP = hp->getCurrentHP();
    //            int deviceId = 0x2001;
    //            if (currentHP == 1)
    //                deviceId = 0x2001;
    //            else
    //                deviceId = 0x2002;
    //            HPCmd::Control(deviceId, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        case KaSCK_HP:
    //        {
    //            params.insert("RFOutput", value);
    //            int currentHP = hp->getCurrentHP();
    //            int deviceId = 0x2003;
    //            if (currentHP == 1)
    //                deviceId = 0x2003;
    //            else
    //                deviceId = 0x2004;
    //            HPCmd::Control(deviceId, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        case KaSSC_HP:
    //        {
    //            params.insert("RFOutput", value);
    //            int currentHP = hp->getCurrentHP();
    //            int deviceId = 0x2005;
    //            if (currentHP == 1)
    //                deviceId = 0x2005;
    //            else
    //                deviceId = 0x2006;
    //            HPCmd::Control(deviceId, 0xFFFF, 0x1, params, HPCmd::UnitParameter, data);
    //            emit signalsUnitDeviceJson(data);
    //            break;
    //        }
    //        default: break;
    //        }
    //    }
}
