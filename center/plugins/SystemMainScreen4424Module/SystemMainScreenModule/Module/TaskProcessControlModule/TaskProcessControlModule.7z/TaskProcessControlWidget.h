#ifndef TASKPROCESSCONTROLWIDGET_H
#define TASKPROCESSCONTROLWIDGET_H

#include "PlanRunMessageDefine.h"
#include "WorkModeXMLReader.h"

#include <QButtonGroup>
#include <QDialog>
#include <QMap>

class HP;
class SystemCaptureProcessControl;

class QComboBox;
class QTreeWidget;
namespace Ui
{
    class TaskProcessControlWidget;
}

// 任务过程控制模块
class TaskProcessControlWidget : public QDialog
{
    Q_OBJECT

public:
    explicit TaskProcessControlWidget(QWidget* parent = nullptr);
    ~TaskProcessControlWidget();

protected:
    void paintEvent(QPaintEvent* event);
    void showEvent(QShowEvent* event);

private:
    void initUI();
    // 初始化快捷控制区域
    void initQuickControlUI();
    // 初始化手动控制区域
    void initManualControlUI();

    void initSlot();
    // 功放显示策略
    void hpTableReare();

    void hpTableReareManual();

    //链路控制的方法
    void manualFunction(ManualType type);
    // 手动控制界面获取选择的设备信息，组成参数宏数据
    void getConfigMacroData(ConfigMacroData& configMacroData);
    // 去改变系统工作方式
    void changeSystemWorkWay();
    // 根据工作模式，改变当前工作模式能够选用的目标个数
    void changeTarget(SystemWorkMode workMode);
    // 第二个测控Tab页
    void changeTarget2(SystemWorkMode workMode);

    // 根据任务代号，改变对于的点频
    void changedPointFreq(QComboBox* taskCodeCombo, QComboBox* pointFreqCombo);
    //这里是判断界面没有选择工作模式或没有选择任务代号的提示
    bool checkMistake();

signals:
    void signalManualFunction(const QString& json);
    void signalsCmdDeviceJson(const QString& json);
    void signalsUnitDeviceJson(const QString& json);

private slots:
    // 刷新卫星数据
    void slotRefreshData();

    // 快捷控制界面测控模式改变
    void slotCKWorkModeChanged(int index);
    void slotCKWorkModeChanged2(int index);
    // 快捷控制界面数传模式改变
    void slotSCWorkModeChanged(int index);
    // 当测控、数传模式改变，或者系统工作方式改变时，是否显示扩频和数传单选按钮
    void slotIsShowRadioBtn();

    // 手动控制界面模式改变
    void slotWorkModeChanged(int index);
    // 特殊处理4424高速数传任务代号下拉框改变时
    void slotGSTaskCodeComboChanged();

    // 快捷控制和手动控制tab界面切换
    void slotContrlTabChanged(int index);

    // 资源释放按钮点击
    void slotResourceReleaseBtnClick();
    // 参数宏下发按钮点击
    void slotSetParamMacroBtnClick();
    // 链路设置按钮点击
    void slotLinkSetBtnClick();
    // 一键校零按钮点击
    void slotOneKeyXLBtnClick();

    /*时间不够，暂时写死*/
    void slotToACUSetProcess(int value);

    void slotPowerSetProcess(double value);

    void slotALCSetProcess(int value);

    void slotOutputProcess(int value);

private:
    Ui::TaskProcessControlWidget* ui;

    SystemCaptureProcessControl* m_systemCaptureProcessControl;

    int index = 1;
    QString m_CurProject;
    /* 高功放要用tab页面 有3个 S ka测控 ka数传 */
    HP* m_sHP;
    HP* m_kaSCHP;
    HP* m_kaCKHP;

    WorkSystem mWorkSystem;

    QButtonGroup mCkTargetNoBtnGroup;   // 快捷控制界面测控第一个Tab主跟目标号按钮组
    QButtonGroup mCkTargetNoBtnGroup2;  // 快捷控制界面测控第二个Tab主跟目标号按钮组

    QButtonGroup mSCTargetNoBtnGroup;  // 快捷控制界面数传主跟目标号按钮组
    QButtonGroup mSDTargetNoBtnGroup;  // 手动控制界面主跟目标号按钮组

    QMap<int, QComboBox*> m_ckCombox;  //快捷控制界面测控的下拉框
    QMap<int, QComboBox*> m_scCombox;  //快捷控制界面数传的下拉框
    QMap<int, QComboBox*> m_sdCombox;  //手动控制界面的下拉框

    QButtonGroup mMasterSlaveLinkBtnGroup;  // 主备链路按钮组

    QMap<SystemWorkMode, QList<QString>> mWorkModeTaskcodeMap;        // 工作模式对应的任务代号的列表
    QMap<QString, QMap<SystemWorkMode, int>> mTaskCodeWorkModeDpMap;  // QMap<任务代号, QMap<工作模式, 点频数>>

    QMap<SystemWorkMode, QWidget*> mDeviceWidgetMap;  // 手动控制栈式控件
};

#endif  // TASKPROCESSCONTROLWIDGET_H
