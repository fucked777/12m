PROJECT_LABEL
-------------

Change the name of a target in an IDE.

Can be used to change the name of the target in an IDE like Visual
Studio.
